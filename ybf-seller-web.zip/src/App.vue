<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
import { isMobile } from '@/utils/validate'
export default {
  name: 'App',

  created() {
    if (isMobile()) {
      this.$router.replace('404-no-mobile')
    }
  },
  beforeMount() {
    window.addEventListener('resize', this.$_resizeHandler)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.$_resizeHandler)
  },

  methods: {
    $_resizeHandler() {
      if (isMobile()) {
        this.$router.replace('404-no-mobile')
      }
    },
  },
}
</script>

<style lang="scss" scoped>
#app {
  background-color: #000;
}
</style>

<style>
* {
  box-sizing: border-box;
}
:root {
  --border: 8px;
  --main-bg: #242322;
  --container-bg: #2d2c2b;
  --sub-text-color: #888683;
  --main-text-color: #ddba82;
  --input-border-color: #4b4845;
  --split-border-color: #3a3938;
  --scrollbar-thumb: rgba(0, 0, 0, 0.3);
}

.split_border {
  width: 100%;
  height: 1px;
  background: var(--split-border-color);
}
.view_content {
  display: flex;
  flex-direction: column;
  height: 100%;
  width: 100%;
  border-radius: 8px;
  background: var(--container-bg);
  padding: 12px 20px 20px 20px;
}
.time_split_box {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}
html {
  font-family: PingFang SC, -apple-system, sans-serif;
}
</style>

<style lang="scss">
.el-loading-mask {
  background-color: rgba(36, 35, 34, 0.9);
}
</style>
