import { accuracy, formatNumber } from '../utils/tools'
export const placeholder = (value, holder = '/') => {
  return value || holder
}

export const filterAccuracy = accuracy

export default {
  install(Vue) {
    Vue.filter('placeholder', placeholder)
    Vue.filter('filterAccuracy', filterAccuracy)
    Vue.filter('formatNumber', formatNumber)
  }
}

