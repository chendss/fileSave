import Vue from 'vue'

const numberRegexpString = '^[-]{0,1}(([\\d]*)|([\\d]+[\\.]{0,1}[\\d]*))$'
export const numberRegexp = new RegExp(numberRegexpString)

const onlyNumberRegexpString = '^[\\d]+$'
export const onlyNumberRegexp = new RegExp(onlyNumberRegexpString)
const only6DigitRegexpString = '^[-]{0,1}(([\\d]*)|([\\d]+[\\.]{0,1}[\\d]{0,6}))$'
export const only6DigitRegexp = new RegExp(only6DigitRegexpString)

function check (value, oldValue, modifiers) {
  if (value === undefined || value === null || value === '') {
    return value
  }
  let regexpString
  switch (true) {
    case modifiers.only:
      regexpString = onlyNumberRegexpString
      break
    case modifiers.only6Digit:
      regexpString = only6DigitRegexpString
      break
    default:
      regexpString = numberRegexpString
  }
  if (modifiers.multiple) {
    regexpString = regexpString.substr(1, regexpString.length - 2)
    regexpString = `^${regexpString}(\\,(${regexpString})*)*$`
  }
  const regexp = new RegExp(regexpString)
  if (regexp.test(value)) {
    return value
  }
  return oldValue
}

Vue.directive('number', {
  bind (el, binding, vnode) {
    const { modifiers } = binding
    const component = vnode.componentInstance
    const value = check(component.value, '', modifiers)
    if (component.value === value) {
      return
    }
    component.value = value
  },
  update (el, binding, vnode) {
    const { modifiers } = binding
    const component = vnode.componentInstance
    if (component.$oldNumberValue === undefined) {
      component.$oldNumberValue = ''
    }
    const value = check(component.value, component.$oldNumberValue, modifiers)
    component.$oldNumberValue = value
    if (component.value === value) {
      return
    }
    if (vnode.data && vnode.data.model) {
      vnode.data.model.callback(value)
    } else {
      component.$emit('input', value)
    }
  }
})
