import Vue from 'vue'
import './filters/number'

import * as Cookies from 'js-cookie'

import 'normalize.css/normalize.css'

import ELEMENT from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'

// import * as fundebug from 'fundebug-javascript'
// import fundebugVue from 'fundebug-vue'
// import 'fundebug-revideo'

import './assets/styles/element-variables.scss'
// global css
import './assets/styles/index.scss'

import App from './App'
import store from './store'
import router from './router/routers'

import './assets/icons' // icon
import './router/index' // permission control

Vue.use(ELEMENT, {
  size: Cookies.get('size') || 'small' // set element-ui default size
})

// if (process.env.VUE_APP_ENV === 'prod' || process.env.VUE_APP_ENV === 'prod') {
//   fundebug.apikey = '25158ed47fde297843eeef187eb14c402a762f5621779e17f3ec83e2a46252b6'
//   fundebugVue(fundebug, Vue)
// }

// 扩展，包括全局组件，全局mixin...
import '@/utils/ext.js'

Vue.config.prodTip = false

new Vue({
  el: '#app',
  router,
  store,
  render: h => h(App)
})

