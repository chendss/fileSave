import { get as lodashGet, set } from 'lodash-es'

/**
 * 根据 object对象的path路径获取值。 如果解析 value 是 undefined 会以 defaultValue 取代
 * path支持数组，当第一个路径取不到时则使用第二个路径
 *
 * @param {any} obj
 * @param {string|string[]} path
 * @param {any} def
 * @returns
 */
export const get = (obj, path, def) => {
  let value = null
  const rules = [null, 'null', '', undefined]
  const pathList = path instanceof Array ? path : [path]
  for (const p of pathList) {
    value = lodashGet(obj, `${p}`, null)
    if (!rules.includes(value)) {
      return value
    }
  }
  return def
}

export const transSelectOptionsToObj = (selectOptions) => {
  const optionsObj = {}
  for (const objKey in selectOptions) {
    optionsObj[objKey] = {}

    if (!selectOptions[objKey]) {
      continue
    }
    selectOptions[objKey].forEach(item => {
      const { value = '', key } = item
      set(optionsObj, `[${objKey}][${key}]`, value)
    })
  }
  return optionsObj
}

/**
* 兼容苹果浏览器的event获取方法
*
* @param {*} e
* @returns
*/
export const getEventPath = (e) => {
  const path = get(e, 'path', null)
  if (path == null) {
    if (e.composedPath) {
      return e.composedPath()
    }
    return []
  }
  return path
}

export const jsonParse = (text) => {
  try {
    return JSON.parse(text)
  } catch (error) {
    return {}
  }
}
