import { get } from '@/utils/tools'
import { formatNumber } from '@/utils/mathe'
import { isNaN } from 'lodash'
import dayjs from 'dayjs'

export const getTableValue = (row, column) => {
  const property = get(column, 'property', null)
  const value = get(row, property, null)
  if (value == null || value === '' || isNaN(value)) {
    return '/'
  }
  return value
}

export const getTableTimeValue = (row, column) => {
  const property = get(column, 'property', null)
  const value = get(row, property, null)
  if (value == null || value === '' || isNaN(value) || value === '/') {
    return '/'
  }
  return dayjs(value).format('YYYY-MM-DD HH:mm:ss')
}

export const getTableTimeSplitValue = (row, property) => {
  const value = get(row, property, null)
  if (value == null || value === '' || isNaN(value) || value === '/') {
    return '/'
  }
  const obj = dayjs(value)
  return [obj.format('YYYY-MM-DD'), obj.format('HH:mm:ss')]
}

export const getTableEnumValue = (row, property, enumObj, enumKey) => {
  const value = `${get(row, property, null)}`
  const result = get(enumObj, `${enumKey}[${value}]`, '/')
  return result
}

export const getTradingPair = (row, propertys) => {
  const [key1, key2] = propertys
  const value1 = get(row, key1, null)
  const value2 = get(row, key2, null)
  if (value1 == null && value2 == null) {
    return '/'
  }
  return `${value1} / ${value2}`
}

export const findValueByArray = (key, array) => {
  const obj = array.find(a => `${get(a, 'key', '')}` === `${key}`)
  return get(obj, 'value', null)
}

export const getUnitPrice = (row, key) => {
  const value = `${get(row, key, null)}`
  if (value == null && value === '') {
    return '/'
  }
  return `￥${formatNumber(value, 'CNY')}/USDT`
}

export const getNumber = (row, key, coinType, floatLength = 6, isGroup = false) => {
  const value = `${get(row, key, null)}`
  if (value == null && value === '') {
    return '/'
  }
  if (coinType) {
    return `${formatNumber(value, coinType, undefined, isGroup)} ${coinType}`
  }
  return `${formatNumber(value, undefined, floatLength, isGroup)}`
}

export const getEnumLabelByObj = (value, options) => {
  return get(options, `${value}`, '')
}
