import axios from 'axios'
import router from '@/router'
import encrypt from './encrypt'
import { urlEncrypter } from '@/utils/url-encrypt'
import { Message, Notification } from 'element-ui'
import store from '../store'
import { getToken, removeToken } from '@/utils/auth'
import { get } from './tools'

// const baseURL = import.meta.env.DEV ? process.env.VUE_APP_BASE_API : '/'
const baseURL = process.env.VUE_APP_BASE_API
const service = axios.create({
  baseURL,
  timeout: 10000
})

if (process.env.VUE_APP_ENV !== 'prod') {
  window.decrypt = (text) => JSON.parse(encrypt.decrypt(text))
}
let loadDeviceIdPromise = Promise.resolve()
loadDeviceIdPromise = import('@fingerprintjs/fingerprintjs')
  .then((m) => {
    return m.default
  })
  .then((fs) => fs.load())
  .then((fp) => fp.get())
  .then((result) => {
    const deviceId = result.visitorId
    return deviceId
  })

const errorHandle = (error) => {
  const res = get(error, 'response', '')
  const silence = get(error, 'response.config.silence', false)
  let result = ''
  try {
    if (import.meta.env.VUE_APP_ENCODE === 'true') {
      result = JSON.parse(encrypt.decrypt(res.data))
      const code = get(result, 'code', 500)
      const msg = get(result, 'msg', '服务器繁忙')
      const message = `服务器繁忙: ${code}`
      !silence && Message.error(message)
      console.log('接口不行了', code, msg)
      return { code, message }
    } else {
      const dataCode = get(res, 'data.code') + ''
      const dataMsg = get(res, 'data.msg', '') + ''
      if (dataCode && dataMsg) {
        const message = `协议错误:${dataCode}`
        !silence && Message.error(message)
        console.log('接口不行了', dataCode, dataMsg)
        return { code: dataCode, message }
      }
    }
  } catch (err) {
    !silence && Message.error('未知服务器错误')
    return {}
  }
}

export const getExtraConfig = () => {
  const result = {
    deviceName: 'PC',
    platform: 6,
    lbs: '',
    network: -1,
    screenSize: `{${document.body.clientWidth}, ${document.body.clientHeight}}`,
    appType: window.location.href.includes('bh') ? 1 : 2
  }
  const simulation = localStorage.getItem('simulation') || '0'
  if (simulation === '1') {
    // result.platform = 2
    // result.osVersion = '12'
    // result.deviceName = '22021211RC'
    // result.appVersion = '0.1.406'
    // result.appId = 'a.b.dc.w.ybf.beta'
    // result.channelCode = 'official'
    // result.isDeviceIdError = false
    // result.deviceId = '2bfd95abbe33938f8b1f9913e4272fe51-1678244366085-9a3fc80c-3737'
    // result.mac = '9e:e2:ff:dc:f6:e1'
    // result.appType = 2
    result.token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJMT0dJTl9TRUNVUklUWV9DT0RFIiwiTklDS05BTUUiOiJ1RHBzYVkiLCJVU0FHRV9UWVBFIjoiTE9HSU5fU0VDVVJJVFlfQ09ERSIsIm5iZiI6MTY3ODUwNjk2MSwiaXNzIjoiZGMuY29tIiwiTE9HSU5fS0VZIjoiKzg2IDE1OTIwMDE0NDk5IiwiU1VCSkVDVCI6IkxPR0lOX1NFQ1VSSVRZX0NPREUiLCJFWFBJUkVTX0FUIjoiMjAyMy0wNi0xOSAxMTo1NjowMiIsIlVTRVJfSUQiOiIxNjIyNTY3IiwiZXhwIjoxNjg3MTQ2OTYyLCJpYXQiOjE2Nzg1MDY5NjF9.rDydh1Ip5k3xVK2Fi8m37hGepP_4PoPYgSSHp0sMWVo'
  }
  return result
}

// request 拦截器
service.interceptors.request.use(
  async (config) => {
    config.url = '/gw' + config.url
    // const isProd = process.env.VUE_APP_ENV === 'prod'
    // if (isProd) {
    //   await getUrl(process.env.baseUrl, config)
    // }
    const deviceId = await loadDeviceIdPromise
    config.headers.deviceId = deviceId
    config.headers['Content-Type'] = 'application/json'
    let userId = window.localStorage.getItem('userId')
    const day3 = 3600 * 24 * 3 * 1000
    if (!userId || Date.now() - Math.abs(userId) > day3) {
      userId = -Date.now()
      window.localStorage.setItem('userId', userId)
    }
    config.data = {
      // param 里面传参 其余是公共部分, 公共部分有13个参数
      // token: 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJMT0dJTl9TRUNVUklUWV9DT0RFIiwiTklDS05BTUUiOiJnZW5IdEIiLCJVU0FHRV9UWVBFIjoiTE9HSU5fU0VDVVJJVFlfQ09ERSIsIm5iZiI6MTY3NjEyMTc3NywiaXNzIjoiZGMuY29tIiwiTE9HSU5fS0VZIjoiKzg2IDE4NTAwMDAwMDAxIiwiU1VCSkVDVCI6IkxPR0lOX1NFQ1VSSVRZX0NPREUiLCJVU0VSX0lEIjoiMTAxMjU3ODIiLCJFWFBJUkVTX0FUIjoiMjAyMy0wMi0xMSAyMTo1Mjo1OCIsImV4cCI6MTY3NjEyMzU3OCwiaWF0IjoxNjc2MTIxNzc3fQ.KUybxUa1TSRqw2XJHFIergN725OVYL_iHO28r2l_npk',
      token: getToken(),
      deviceId,
      param: config.data,
      notificationStatus: 0,
      timestamp: new Date().getTime(),
      osVersion: navigator.userAgent,
      // 'deviceId': '2CCD0382-7962-4D2B-8AE4-27968C93A8F9',
      // 'appId': 'com.wallet.bihui',
      // 'userId': '100200',
      // 'userId': '100344',
      userId: parseInt(userId),
      ...getExtraConfig(),
    }
    config.headers['dt-nonce'] = encrypt.createNonce()
    config.headers['dt-encrypted'] = false
    // if (import.meta.env.DEV) {
    //   console.log('========request=======', config.url)
    //   console.log(config.data)
    // }
    if (import.meta.env.VUE_APP_ENCODE === 'true') {
      config.headers['dt-timestamp'] = encrypt.createTimestamp()
      const encryptData = encrypt.encrypt(config.data)
      config.headers['dt-sign'] = encrypt.createSign(
        encryptData,
        config.headers['dt-nonce'],
        config.headers['dt-timestamp']
      )
      config.headers['dt-encrypted'] = true
      config.headers['dt-encrypt-version'] = 3
      config.headers['dt-gzipped'] = true
      config.headers['dt-client-key'] = encrypt.clientPublicKey

      // URL动态加密
      await urlEncrypter.encrypt(config)
      config.data = encryptData
    }

    return config
  },
  (error) => {
    return Promise.resolve({
      code: error.code,
      message: error.message || JSON.stringify(error)
    })
  }
)

// response 拦截器
service.interceptors.response.use(
  (response) => {
    if (import.meta.env.VUE_APP_ENCODE === 'true') {
      response.data = JSON.parse(encrypt.decrypt(response.data))
    }
    const res = response.data

    // 错误码处理
    if (![200, 2000].includes(res.code)) {
      if (res.code === 4004) {
        removeToken()
        location.hash.includes('/login') ? location.reload() : router.push('/login')
      }
      if (res.code === 309) {
        removeToken()
        !location.hash.includes('/login') && router.push('/login')
        Notification.error({
          title: res.msg || res.message || 'Error',
          duration: 5000
        })
      }
      if (res.code === 202 && !location.hash.includes('/maintenance')) {
        router.replace('/maintenance')
      }
      return Promise.reject(res)
    } else {
      return res
    }
  },
  (error) => {
    return Promise.resolve(errorHandle(error))
  }
)

export default service
