import Vue from 'vue'
import { transSelectOptionsToObj } from '@/utils/tools'
import Pagination from '@/components/Pagination'
import ResetLoadingBtn from '@/components/ResetLoadingBtn'
/**
 * 全局组件
 */

// 注册全局组件Pagination
Vue.component('Pagination', Pagination)

Vue.component('ResetLoadingBtn', ResetLoadingBtn)
/**
 * 全局mixin
 */

Vue.mixin({
  methods: {
    validateForm (formName, cb) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          cb.call(this)
        }
      })
    },
    onCopy () {
      this.$message.success('复制成功')
    },
    onError () {
      this.$message.console.error('复制失败')
    },
    transSelectOptionsToObj (selectOptions) {
      return transSelectOptionsToObj(selectOptions)
    }
  }
})

