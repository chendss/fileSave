import CardImg from '@/assets/images/choose_pay_credit-card.png'
import Alipay from '@/assets/images/choose_pay_alipay.png'
import Wechat from '@/assets/images/choose_pay_wechat.png'

export const payMethodMap = {
  1: '银行卡',
  2: '支付宝',
  3: '微信',
}

export const payImgTypeMap = {
  1: CardImg,
  2: Alipay,
  3: Wechat,
}

export const publishPendingOrderType = [
  {
    key: '5',
    value: '特惠出售'
  },
  // {
  //   key: '1',
  //   value: '普通出售'
  // },
]

export const pendingOrderSelect = [
  {
    key: [0, 1, 2, 6, -1, 4].join(':'),
    value: '全部状态',
  },
  {
    key: [0, 1, 2].join(':'),
    value: '挂单中',
  },
  {
    key: '6',
    value: '已售罄',
  },
  {
    key: [-1, 4].join(':'),
    value: '已下架',
  },
]
/** 挂单交易类型 */
export const orderTransactionMap = {
  0: '购买',
  1: '出售'
}

/** 挂单创建类型 */
export const pendingCreateTypeMap = {
  5: '特惠'
}
/** 法定货币类型 */
export const legalCurrencyTypeMap = {
  '-1': 'CNY',
  '-2': 'USD'
}

/** 币种枚举 */
export const coinTypeMap = {
  1: 'USDT',
  0: 'BTC',
  2: 'ETH',
  3: 'TRX'
}

export const symbolMap = {
  '-1': '￥',
  '-2': '$'
}

export const buyOrderTypeMap = {
  101: '待上传流水',
  102: '待审核流水',
  0: '待付款',
  2: '待确认付款',
  1: '待对方放币',
  4: '申诉中',
  100: '交易成功',
  '-1': '交易取消',
}

export const sellOrderTypeMap = {
  101: '待上传流水',
  102: '待审核流水',
  0: '待对方付款',
  2: '待确认付款',
  1: '待对方放币',
  4: '申诉中',
  100: '交易成功',
  '-1': '交易取消',
}

/**
* 获得订单状态枚举值
*
* @param {*} orderType 买单0 卖单1
*/
export const getOrderTypeMap = (orderType) => {
  if (`${orderType}` === '0') {
    return buyOrderTypeMap
  }
  return sellOrderTypeMap
}
