import dayjs from 'dayjs'
import { serverTime } from '@/api/user'
import { AES } from '@/utils/aes-encrypt'

import utc from 'dayjs/plugin/utc'
import timezone from 'dayjs/plugin/timezone'
dayjs.extend(utc)
dayjs.extend(timezone)

class UrlEncrypter {
  constructor() {
    this.prefix = '/RoaVGWBm'
    this.keysDev = {
      key: 'QLgQS0Ap6spkk7y9ES8xP4EojDCbdhac',
      iv: 'Xhw0CK7s8F3JVEE0'
    }
    this.keysProd = {
      key: 'xBaZL9OEWjn8eTYolazycpNi5PHZh749',
      iv: 'ZVeTgve2qtnGJChO'
    }
    this.timeDiff = 0
    // 是否已经校对过服务器时间
    this.alignTimeFlag = false
    this.alignTime()
  }

  now() {
    return dayjs().valueOf()
  }

  async alignTime() {
    if (this.alignTimeFlag) {
      return
    }
    try {
      const resp = await serverTime()
      const servTime = resp.data.serverTime
      const servTimestamp = dayjs.tz(servTime, 'Asia/Shanghai').valueOf()
      this.timeDiff = servTimestamp - this.now()
      this.alignTimeFlag = true
    } catch (e) {
      console.log('align server time error:', e)
    }
  }

  async time() {
    await this.alignTime()
    return this.now() + this.timeDiff
  }

  async encryptURL(url) {
    // url = '/gw' + url
    const keys = process.env.VUE_APP_ENV === 'prod' ? this.keysProd : this.keysDev
    const mixed = String(await this.time()) + url
    const aes = new AES(keys.key, keys.iv)
    let enc = aes.encrypt(mixed)
    enc = enc.replace(/\+/g, '-')
    enc = enc.replace(/\//g, '_')
    enc = enc.replace(/=/g, '')
    return this.prefix + enc
  }

  async encrypt(axiosRequestConfig) {
    const config = axiosRequestConfig
    let url = config.url
    if (!url.startsWith('/')) {
      url = '/' + url
    }
    config.url = await this.encryptURL(url)
    config.headers.SKKTW = 'web'
    config.headers.QHUJK = '1'
  }
}

export const urlEncrypter = new UrlEncrypter()
