import dayjs from 'dayjs'

export const getRangeTime = (dx, unit) => {
  const today = dayjs()
  const time = [
    today.add(dx, unit).format('YYYY-MM-DD 00:00:00'),
    today.format('YYYY-MM-DD 23:59:59')
  ]
  return time
}
