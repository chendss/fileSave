import { getState } from '@/settings'
import { nth, isNaN } from 'lodash-es'
import BigNumber from 'bignumber.js'

const coinList = {
  'USDT': 6,
  'BTC': 6,
  'CNY': 2,
  'USDT_OMNI': 6,
  'USDT-OMNI': 6,
  'USDT-ERC20': 6,
  'USDT_ERC20': 6,
  'USDT_TRC20': 6,
  'USDT-TRC20': 6,
  'default': 6
}

export const accountingFormatNumber = (val, formatLength, group = true) => {
  try {
    const fmt = {
      prefix: '',
      decimalSeparator: '.',
      groupSeparator: ',',
      groupSize: group ? 3 : 0,
      secondaryGroupSize: 0,
      fractionGroupSeparator: ' ',
      fractionGroupSize: 0,
      suffix: ''
    }
    const bg = new BigNumber(val)
    if (formatLength == null) {
      const value = bg.toFormat(fmt)
      return value
    }
    const value = bg.toFormat(formatLength, fmt)
    return value
  } catch (error) {
    const value = new Intl.NumberFormat(undefined, {
      minimumFractionDigits: formatLength,
      useGrouping: group
    }).format(val)
    return value
  }
}

export function minus (a, b) {
  return new BigNumber(a).minus(b).toString()
}

export function plus (a, b) {
  return new BigNumber(a).plus(b).toString()
}

export function isGt (a, b) {
  return new BigNumber(a).isGreaterThan(b)
}

/**
* 判断a是否大于等于b
*
* @param {*} a
* @param {*} b
* @returns
*/
export const comparedTo = (a, b, equal = true) => {
  const result = new BigNumber(a).comparedTo(b)
  if (equal) {
    return result === 0 || result === 1
  } else {
    return result === 1
  }
}

/**
* 两数相乘
*
* @param {*} a
* @param {*} b
* @returns
*/
export const times = (a, b) => {
  const result = new BigNumber(a).times(b)
  return result
}

export function toFixed (val, digitalCurrencyType) {
  if (Object.prototype.toString.call(val) === '[object Null]') {
    return 0
  }
  if (Object.prototype.toString.call(val) === '[object Undefined]') {
    return 0
  }
  let decimal = 2

  if (digitalCurrencyType) {
    decimal = getState(Number(digitalCurrencyType), 'digitalCurrencyType')
      .decimal
  }
  // 向下保留
  return BigNumber(val).toFixed(decimal, 1)
}

export function toFixedByThousands (val, digitalCurrencyType) {
  const toFixedResult = toFixed(val, digitalCurrencyType)
  const [value, decimal] = toFixedResult.split('.')
  const result = Number(value).toLocaleString('en-US')
  return decimal ? `${result}.${decimal}` : result
}

/**
* 数字格式化，只做展示作用，不改变数字本身，并且不做四舍五入
*
* @param {number} n 数字
* @param {string} [coinType='default'] 币种类型
* @param {number?} formatLength 保留几位小数
* @param {boolean} [isGroup=true] 是否千分位逗号隔开
* @returns
*/
export const formatNumber = (n, coinType = 'default', formatLength, isGroup = false) => {
  if (isNaN(n) || n == null) {
    return ''
  } else if (n === '' || (!Number(n) && Number(n) !== 0)) {
    return n
  }
  const coinTypeNumber = coinList[coinType] || coinList[(`${coinType || ''}`).toLocaleUpperCase()]
  const floatLength = formatLength == null ? coinTypeNumber : formatLength
  const num = n + ''
  const [integer, decimal] = num.split('.')
  const formatInterger = accountingFormatNumber(integer, floatLength, isGroup)
  if (decimal == null) {
    if (nth(`${formatInterger}`, -1) === '.') {
      return formatInterger.replace('.', '')
    }
    return formatInterger.padEnd(floatLength, '0')
  } else {
    const formatInterger_ = accountingFormatNumber(integer, 0, isGroup)
    const fn = decimal.slice(0, floatLength).padEnd(floatLength, '0')
    let result = `${formatInterger_}.${fn}`
    if (nth(result, -1) === '.') {
      result = result.replace('.', '')
    } else {
      if (num[0] === '-' && result[0] !== '-') {
        result = `-${result}`
      }
    }
    return result
  }
}

/**
* 处理货币进度
*
* @param {*} n
* @param {string} [coinType='default']
* @returns
*/
export const accuracy = (n, coinType = 'BTC') => {
  if (`${n}` === '0') {
    return n
  }
  if (isNaN(n) || n == null) {
    return '/'
  }
  return formatNumber(n, coinType, undefined, false)
}
