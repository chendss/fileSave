<template>
  <div>
    <div id="id-div-body">
      我的定单
    </div>
  </div>
</template>

<script>

export default {
  computed: {
  },
  methods: {
  }
}

</script>
<style lang="scss" scoped>
</style>
