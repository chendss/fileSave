import { sample } from 'lodash-es'

export const detailData = {
  sumNumber: 59999999999988,
  overNumber: 999,
  surplus: 999,
  transactionIn: 123123,
  coin: 'USDT',
  amountReceived: 12312344,
  price: 666,
  surplusReceived: 8888,
  priceType: 'CNY'
}

export const enumArray = [
  {
    key: '0',
    value: '交易完成',
  },
  {
    key: '1',
    value: '交易取消',
  },
  {
    key: '2',
    value: '待付款',
  },
  {
    key: '3',
    value: '待卖方放币',
  },
]

export const listData = new Array(43).fill('').map((_, index) => (
  {
    id: '0',
    orderId: '141086218019009331222',
    pendingOrderId: '141086218019009331255',
    type: '出售-特惠',
    methodPayment: '银行卡',
    termsPayment: '支付宝',
    price: '6.47',
    coin: 'USDT',
    priceType: 'CNY',
    transactionAmount: 20,
    transactionCount: 5433,
    time: '2021-06-30 22:00:00',
    status: sample(enumArray.map(e => e.key)),
  }
))

