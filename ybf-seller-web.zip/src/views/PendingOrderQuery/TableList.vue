<template>
  <Table :getData="getData" style="width: 100%" class="pending_query_table" :row-class-name="rowClassName">
    <TableColumn label="订单号" prop="id" width="80px" />
    <TableColumn label="类型" prop="typeStr" width="100px" />
    <TableColumn label="挂单订单号" prop="refSellerOrderPendingId" width="80px" />
    <TableColumn label="收/付款方式" prop="payMethodStr" width="80px" />
    <TableColumn label="单价" prop="priceStr" width="120px" />
    <TableColumn :pairKeys="['legalCurrencyStr', 'coinTypeStr']" label="交易对" valueType="pair" />
    <TableColumn label="交易金额" prop="legalCurrencyAmountStr" />
    <TableColumn label="交易数量" width="140px" prop="transformNumber" />
    <TableColumn label="发布时间" width="80px">
      <template v-slot="{ row }">
        <div class="time_split_box">
          <span>{{ getTableTimeSplitValue(row, 'createdAt')[0] }}</span>
          <span>{{ getTableTimeSplitValue(row, 'createdAt')[1] }}</span>
        </div>
      </template>
    </TableColumn>
    <TableColumn label="状态" prop="statusStr" width="80px" />
    <TableColumn label="操作" width="90px">
      <template v-slot="{ row }">
        <div class="action_btn">
          <Button btnType="text" @click="query(row)"> 查看 </Button>
          <Button v-if="!rowClassName({ row })" btnType="text" @click="dispose(row)"> 去处理 </Button>
        </div>
      </template>
    </TableColumn>
  </Table>
</template>

<script>
import { TableColumn, Button, Table } from '@/components'
import { get } from '@/utils/tools'
import { getTableTimeSplitValue } from '@/utils/table'
import { formatNumber } from '@/utils/mathe'
import { PendingOrder } from '@/api'
export default {
  components: { TableColumn, Button, Table },
  props: {
    enumType: {
      type: Object,
      default: () => ({}),
    },
    orderId: {
      type: String,
      default: '',
    },
  },
  data() {
    return {}
  },
  computed: {},
  methods: {
    get,
    formatNumber,
    getTableTimeSplitValue,
    query(row) {
      this.$emit('query', row)
    },
    dispose(row) {
      this.$emit('dispose', row)
    },
    rowClassName({ row }) {
      const isCancel = get(row, 'isCancel', false)
      if (isCancel) {
        return 'discard_row'
      }
      return ''
    },
    async getData(pagination) {
      try {
        this.loading = true
        const params = {
          statusList: [],
          createType: 5,
          refSellerOrderPendingId: this.orderId,
          page: {
            current: pagination.page,
            size: pagination.pageSize,
          },
        }
        const res = await PendingOrder.getDetailList(params)
        return res
      } catch (error) {
        console.log('table组件发生错误', error)
      } finally {
        this.loading = false
        this.init = false
      }
    },
  },
}
</script>

<style lang="scss" scoped>
.pending_query_table {
  .action_btn {
    display: inline-flex;
    align-items: center;
    justify-content: flex-start;
    ::v-deep {
      .custom_button + .custom_button {
        margin-left: 10px;
      }
    }
    .hidden_btn {
      visibility: hidden;
    }
  }
  ::v-deep {
    .discard_row {
      .cell {
        color: var(--sub-text-color) !important;
      }
    }
  }
}
</style>
