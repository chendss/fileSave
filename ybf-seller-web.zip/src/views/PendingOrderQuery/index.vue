<template>
  <Page id="id-pending-order-query">
    <div class="header">
      <span>挂单</span>
      <span class="id">ID</span>
      <span class="order_id">{{ orderId }}</span>
    </div>
    <Detail :orderId="orderId" />
    <div class="split_border" />
    <TableList :enumType="enumType" :list-data="listData" :orderId="orderId" />
  </Page>
</template>

<script>
import { Page } from '@/components'
import TableList from './TableList.vue'
import Detail from './Detail.vue'
import { transSelectOptionsToObj } from '@/utils/tools'
import { enumArray, listData } from './const'
export default {
  components: { Detail, TableList, Page },
  data() {
    return {
      timer: Math.random(),
      listData,
      enumType: transSelectOptionsToObj({ status: enumArray }),
      detailData: {},
    }
  },
  computed: {
    orderId() {
      return this.$route.query.order_id
    },
  },
}
</script>

<style lang="scss" scoped>
#id-pending-order-query {
  .header {
    margin-bottom: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    width: max-content;
    padding: 12px 20px;
    background: var(--main-bg);
    border: 1px solid var(--split-border-color);
    border-radius: var(--border);
    > span {
      font-size: 14px;
      color: var(--sub-text-color);
      letter-spacing: 0;
      line-height: 14px;
      font-weight: 400;
    }
    .id {
      font-weight: 700;
    }
    .order_id {
      color: var(--main-text-color);
    }
  }
  .split_border {
    margin: 16px 0;
  }
}
</style>
