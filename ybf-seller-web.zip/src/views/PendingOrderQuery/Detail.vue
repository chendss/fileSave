<template>
  <div class="query_detail">
    <div class="column">
      <div class="item_box">
        <label>挂单总数量</label>
        <span class="main">{{ getValue('amount') }}</span>
        <div class="border_right" />
        <div class="border_bottom" />
      </div>
      <div class="item_box">
        <label>已收款金额</label>
        <span class="red_text">{{ `￥${getValue('legalCurrencyAmount', 'legalCurrency', false)}` }}</span>
        <div class="border_right" />
      </div>
    </div>
    <div class="column">
      <div class="item_box">
        <label>已成交数量</label>
        <span>{{ getValue('finishTradeAmount') }}</span>
        <div class="border_bottom" />
      </div>
      <div class="item_box">
        <label>当前参考价</label>
        <span>{{ currentPrice() }}</span>
      </div>
    </div>
    <div class="column">
      <div class="item_box">
        <label>剩余数量</label>
        <span>{{ getValue('availableAmount') }}</span>
        <div class="border_bottom" />
      </div>
      <div class="item_box">
        <label>预计剩余收款</label>
        <span>{{ `￥${getValue('estimatedRemainingPayment', 'legalCurrency', false)}` }}</span>
      </div>
    </div>
    <div class="column">
      <div class="item_box">
        <label>交易中数量</label>
        <span>{{ getValue('totalFrozenAmount') }}</span>
        <div class="border_bottom" />
      </div>
    </div>
  </div>
</template>

<script>
import { get } from '@/utils/tools'
import { formatNumber } from '@/utils/mathe'
import { PendingOrder } from '@/api'
export default {
  props: {
    orderId: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      data: {},
    }
  },
  mounted() {
    this.refreshData()
  },
  destroyed() {
    clearTimeout(this.timer)
  },
  methods: {
    formatNumber,
    get,
    async refreshData() {
      const res = await PendingOrder.getCommitmentOrderDetail(this.orderId)
      this.data = res
      console.log('刷新详情数据', res)
      this.timer = setTimeout(() => {
        this.refreshData()
      }, 5 * 1000)
    },
    getValue(key, coinKey = 'coinType', join = true) {
      const value = get(this.data, key, null)
      if (value == null || value === '') {
        return '/'
      }
      const coin = get(this.data, `${coinKey}`, '')
      if (join) {
        return `${formatNumber(value, coin, undefined, false)} ${coin}`
      }
      return `${formatNumber(value, coin, undefined, false)}`
    },
    currentPrice() {
      const value = get(this.data, 'price', null)
      if (value == null || value === '') {
        return '/'
      }
      const coin = get(this.data, `legalCurrency`, '')
      return `￥${formatNumber(value, coin, undefined, false)} / ${coin}`
    },
  },
}
</script>

<style lang="scss" scoped>
.query_detail {
  background: #333230;
  border-radius: var(--border);
  padding: 8px 0;
  display: flex;
  .column {
    display: inline-flex;
    flex-direction: column;
    &:last-child {
      flex: 1 1 auto;
    }
    .item_box {
      position: relative;
      width: 100%;
      font-size: 14px;
      padding: 8px 20px;
      height: max-content;
      line-height: 14px;
      letter-spacing: 0;
      display: inline-flex;
      flex-direction: column;
      label {
        color: var(--sub-text-color);
        font-weight: 400;
        margin-bottom: 4px;
      }
      span {
        color: var(--sub-text-color);
        font-weight: 700;
        &.red_text {
          color: #ff6060;
        }
        &.main {
          color: var(--main-text-color);
        }
      }
      .border_right {
        position: absolute;
        right: 0;
        width: 1px;
        background: var(--split-border-color);
        top: 0;
        bottom: 0;
        margin: auto;
        height: calc(100% - 16px);
      }
      .border_bottom {
        position: absolute;
        right: 0;
        left: 0;
        width: 100%;
        background: var(--split-border-color);
        bottom: 0;
        margin: auto;
        height: 1px;
      }
    }
  }
}
</style>
