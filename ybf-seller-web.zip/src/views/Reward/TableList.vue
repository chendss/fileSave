<template>
  <Table ref="table" style="width: 100%" class="reward_table" :getData="getData" :version="version">
    <TableColumn label="账单日期" prop="settlementTime" valueType="time" />
    <TableColumn label="当日出售（USDT）" prop="totalAmount" coinType="USDT" valueType="number" />
    <TableColumn label="每U奖励（CNY）" prop="priceDigital" coinType="CNY" valueType="number" />
    <TableColumn label="总奖励（CNY）" valueType="number" prop="profitCNY" :floatLength="2" />
    <TableColumn label="结算单价" prop="price" valueType="unitPrice" />
    <TableColumn label="结算USDT" valueType="number" prop="profitUSDT" coinType="USDT" />
  </Table>
</template>

<script>
import dayjs from 'dayjs'
import { TableColumn, Button, Table } from '@/components'
import { Reward } from '@/api'
import { get } from '@/utils/tools'
export default {
  components: { TableColumn, Button, Table },
  props: {
    time: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      version: 0,
    }
  },
  computed: {},
  mounted() {},
  methods: {
    async getData(pagination) {
      try {
        const startTime = get(this.time, '[0]', '')
        const endTime = get(this.time, '[1]', '')
        const params = {
          assetType: 1,
          startTime: startTime ? dayjs(startTime).format('YYYY-MM-DD 00:00:00') : '',
          endTime: endTime ? dayjs(endTime).format('YYYY-MM-DD 23:59:59') : '',
          page: {
            current: pagination.page,
            size: pagination.pageSize,
          },
        }
        const res = await Reward.getList(params)
        return res
      } catch (error) {
        console.log('table组件发生错误', error)
      }
    },
    refreshTable() {
      this.version += 1
    },
  },
}
</script>

<style lang="scss" scoped>
.reward_table {
  ::v-deep {
  }
}
</style>
