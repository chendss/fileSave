<template>
  <div>
    <Page id="id-div-body">
      <div class="header">
        <DatePickerMonth v-model="time" @change="timeChange" />
      </div>
      <div class="split_border" />
      <TableList ref="table" :time="time" />
    </Page>
  </div>
</template>

<script>
import { getRangeTime } from '@/utils/datetime'
import { DatePickerMonth } from '@/components'
import TableList from './TableList.vue'
import { Page } from '@/components'
export default {
  components: { Page, TableList, DatePickerMonth },
  data() {
    return {
      time: getRangeTime(-1, 'year'),
    }
  },
  computed: {},
  watch: {},
  mounted() {},
  methods: {
    timeChange() {
      const { table } = this.$refs
      if (table) {
        table.refreshTable()
      }
    },
  },
}
</script>
<style lang="scss" scoped>
.header {
  /* padding-left: 2px; */
}
.split_border {
  margin: 12px 0;
}
</style>
