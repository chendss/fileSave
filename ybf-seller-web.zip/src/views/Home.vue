<template>
  <div>
    <div id="id-div-body">
      Home
    </div>
  </div>
</template>

<script>
import { test } from '@/api/login.js'

export default {
  async created() {
    // test()
  }
}

</script>
<style lang="scss" scoped>

</style>
