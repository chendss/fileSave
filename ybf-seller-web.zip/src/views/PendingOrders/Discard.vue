<template>
  <Dialog
    :visible="visible"
    title="您确认要下架挂单吗？"
    width="500px"
    class="pending_dialog"
    :before-close="beforeClose"
  >
    <div class="titps">
      <span v-for="(text, index) in titps" :key="text">{{ `${index + 1}.${text}` }} </span>
    </div>
    <Check v-model="checked" text="我已知晓并同意" />
    <div class="footer">
      <Button btnType="text" @click="cancel">取消</Button>
      <Button :disabled="!checked" :loading="loading" @click="done">确定下架</Button>
    </div>
  </Dialog>
</template>

<script>
import { PendingOrder } from '@/api'
import { Dialog, Button, Check } from '@/components'
import { get } from '@/utils/tools'
export default {
  components: { Dialog, Button, Check },
  props: {
    visible: {
      type: Boolean,
      default: () => false,
    },
    currentRow: {
      type: Object,
      default: () => {
        return {}
      },
    },
  },
  data() {
    return {
      loading: false,
      titps: [
        '下架挂单后，您仍需要继续处理未完成的订单',
        '仅会退还您挂单剩余数量数字币',
        '正在交易中的订单不会受挂单下架的影响，将会继续交易。',
        '交易中的数字币，将不会立即退还给您',
      ],
      checked: false,
    }
  },
  watch: {
    visible() {
      Object.assign(this.$data, this.$options.data())
    },
  },
  methods: {
    beforeClose(done) {
      this.$emit('close')
      done?.()
    },
    cancel() {
      this.beforeClose()
    },
    async done() {
      console.log('currentRow', this.currentRow)
      this.loading = true
      try {
        const id = get(this.currentRow, 'id', '')
        const res = await PendingOrder.cancelPendingOrder(id)
        if (get(res, 'success', false) === true) {
          this.$emit('done')
          this.beforeClose()
        }
      } catch (error) {
        console.log('下架失败', error)
      } finally {
        this.loading = false
      }
    },
  },
}
</script>

<style lang="scss" scoped>
.pending_dialog {
  ::v-deep {
    .titps {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: flex-start;
      padding-bottom: 16px;
      span + span {
        margin-top: 6px;
      }
    }
    .custom_check {
      padding-bottom: 24px;
    }
    .footer {
      display: flex;
      align-items: center;
      > span {
        color: var(--sub-text-color);
        margin-left: auto;
        margin-right: 20px;
      }
      button {
        width: 156px;
      }
    }
  }
}
</style>
