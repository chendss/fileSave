<template>
  <Page id="id-pending-order">
    <template v-if="!restrictionView">
      <div class="header">
        <Select v-model="orderStatus" :options="pendingOrderSelect" />
        <Button class="extra_button" @click="publishOrder">发布特惠出售订单</Button>
      </div>
      <div class="split_border" />
      <div class="content">
        <div v-if="extraPendingOrder > 0" class="content_header">
          <Titps :text="`本应用仅能处理特惠挂单，您还有其他 ${extraPendingOrder} 个挂单，请移步APP处理`" />
        </div>
        <TableList
          ref="table"
          class="content_table"
          :selectStatus="orderStatus"
          :enumType="enumType"
          @discard="discard"
          @publish="publishOrder"
        />
      </div>
      <Discard
        :visible="discardVisible"
        :currentRow="currentRow"
        @close="discardClose"
        @done="refreshTable"
      />
    </template>
  </Page>
</template>

<script>
import { PendingOrder } from '@/api'
import TableList from './TableList.vue'
import Discard from './Discard.vue'
import { pendingOrderSelect } from '@/utils/mapData'
import { get, transSelectOptionsToObj } from '@/utils/tools'
import { Select, Button, Page, Titps } from '@/components'
export default {
  components: { Select, Button, TableList, Discard, Page, Titps },
  data() {
    return {
      enumType: {},
      currentRow: {},
      pendingOrderSelect,
      extraPendingOrder: 0,
      discardVisible: false,
      restrictionView: false,
      orderStatus: get(pendingOrderSelect, '[0].key', ''),
    }
  },
  computed: {},
  mounted() {
    this.enumType = transSelectOptionsToObj({ status: pendingOrderSelect })
    this.getExtraPendingOrder()
  },
  methods: {
    async getExtraPendingOrder() {
      const res = await PendingOrder.queryInTransactionOrderPendingCount()
      if ('pendingCount' in res) {
        const pendingCount = get(res, 'pendingCount', '0')
        this.extraPendingOrder = Number(pendingCount)
      }
    },
    discard(row) {
      this.currentRow = row
      this.discardVisible = true
    },
    publishOrder() {
      this.$router.push({
        path: 'PublishPendingOrder',
      })
    },
    discardClose() {
      this.currentRow = {}
      this.discardVisible = false
    },
    refreshTable() {
      if (this.$refs['table']) {
        this.$refs['table'].refreshTable()
      }
    },
  },
}
</script>
<style lang="scss" scoped>
#id-pending-order {
  .header {
    display: flex;
    padding-bottom: 12px;
    .extra_button {
      margin-left: auto;
    }
    ::v-deep {
      .custom_select {
        z-index: 2;
      }
    }
  }
  .content {
    padding: 16px 0;
    .content_header {
      padding-bottom: 16px;
    }
  }
}
</style>
