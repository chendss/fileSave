<template>
  <div class="table_box_parent">
    <Table
      v-show="!isEmpty"
      ref="table"
      :getData="getData"
      style="width: 100%"
      class="pending_table"
      :version="version"
      :row-class-name="rowClassName"
      @tableRenderOver="tableRenderOver"
    >
      <TableColumn label="挂单ID" prop="id" width="150px" />
      <TableColumn label="类型" prop="typeStr" width="100px" />
      <TableColumn label="收款方式" prop="payMethodStr" width="60px" />
      <TableColumn label="单价" prop="priceStr" width="120px" />
      <TableColumn prop="pairStr" label="交易对" width="100px" />
      <TableColumn label="挂单数量" width="140px">
        <template v-slot="{ row }">
          <span>{{ `${formatNumber(row.amount, row.coinTypeStr)} ${row.coinTypeStr}` }}</span>
        </template>
      </TableColumn>
      <TableColumn label="已成交/挂单金额" width="150px" prop="donePriceStr" />
      <TableColumn label="发布时间" width="80px">
        <template v-slot="{ row }">
          <div class="time_split_box">
            <span>{{ getTableTimeSplitValue(row, 'createdAt')[0] }}</span>
            <span>{{ getTableTimeSplitValue(row, 'createdAt')[1] }}</span>
          </div>
        </template>
      </TableColumn>
      <TableColumn label="状态" prop="status" :enumType="transformEnumType" valueType="enum" width="60px" />
      <TableColumn label="操作" width="80px">
        <template v-slot="{ row }">
          <div class="action_btn">
            <Button btnType="text" @click="query(row)">查看</Button>
            <Button :class="rowClassName({ row }) && 'hidden_btn'" btnType="text" @click="discard(row)">
              下架
            </Button>
          </div>
        </template>
      </TableColumn>
    </Table>
    <TableEmpty v-show="isEmpty">
      <div class="extra_text">
        <span>您还没有特惠出售挂单，去 </span>
        <span class="publish" @click="publish">发布一个</span>
      </div>
    </TableEmpty>
  </div>
</template>

<script>
import { set } from 'lodash-es'
import { TableColumn, Button, Table, TableEmpty } from '@/components'
import { pendingOrderSelect } from '@/utils/mapData'
import dayjs from 'dayjs'
import { get } from '@/utils/tools'
import { getTableTimeSplitValue } from '@/utils/table'
import { formatNumber } from '@/utils/mathe'
import { PendingOrder } from '@/api'
export default {
  components: { TableColumn, Button, Table, TableEmpty },
  props: {
    enumType: {
      type: Object,
      default: () => ({}),
    },
    selectStatus: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      version: Math.random(),
      init: true,
      loading: false,
      tableData: [],
    }
  },
  computed: {
    isEmpty() {
      return (
        this.selectStatus === get(pendingOrderSelect, '[0].key', '') &&
        get(this.tableData, 'length', 0) <= 0 &&
        !this.init
      )
    },
    transformEnumType() {
      const result = { ...this.enumType }
      const statusMap = {}
      Object.keys(result.status || {}).forEach((key) => {
        const keys = key.split(':')
        const v = result.status[key]
        keys.forEach((k) => (statusMap[k] = v))
      })
      set(result, 'status', statusMap)
      return result
    },
  },
  mounted() {},
  methods: {
    get,
    dayjs,
    formatNumber,
    getTableTimeSplitValue,
    query(row) {
      const { id } = row
      this.$router.push({
        path: 'PendingOrderQuery',
        query: { order_id: id },
      })
    },
    discard(row) {
      this.$emit('discard', row)
    },
    rowClassName({ row }) {
      const status = `${get(row, 'status', '0')}`
      if (['-1', '4'].includes(status)) {
        return 'discard_row'
      }
      return ''
    },
    async getData(pagination) {
      try {
        this.loading = true
        const params = {
          statusList: this.selectStatus.split(':').map(Number),
          createType: 5,
          page: {
            current: pagination.page,
            size: pagination.pageSize,
          },
        }
        const res = await PendingOrder.getList(params)
        return res
      } catch (error) {
        console.log('table组件发生错误', error)
      } finally {
        this.loading = false
        this.init = false
      }
    },
    refreshTable() {
      this.version = Math.random()
    },
    publish() {
      this.$emit('publish')
    },
    tableRenderOver(data) {
      this.tableData = data.tableData
    },
  },
}
</script>

<style lang="scss" scoped>
.pending_table {
  .action_btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    ::v-deep {
      .custom_button + .custom_button {
        margin-left: 10px;
      }
    }
    .hidden_btn {
      visibility: hidden;
    }
  }
  ::v-deep {
    .cell {
    }
    .discard_row {
      .cell {
        color: var(--sub-text-color) !important;
      }
    }
  }
}
.extra_text {
  margin-top: 30px;
  font-size: 14px;
  color: var(--sub-text-color);
  letter-spacing: 0;
  text-align: center;
  line-height: 14px;
  font-weight: 400;
  .publish {
    cursor: pointer;
    color: var(--main-text-color);
  }
}
</style>
