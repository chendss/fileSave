export const options = [
  {
    key: '',
    value: '全部状态',
  },
  {
    key: '0',
    value: '发布中',
  },
  {
    key: '1',
    value: '已下架',
  },
  {
    key: '2',
    value: '挂单中',
  },
]

export const listData = new Array(247).fill('').map((_, index) => ({
  id: `${index}`,
  orderId: '1410246666560438272',
  type: '出售-特惠',
  termsPayment: '银行卡',
  price: '6.47',
  coin: 'USDT',
  priceType: 'CNY',
  orderNumber: 20,
  overNumber: 543388,
  orderPrice: 1000022,
  time: '2021-06-30 22:00:00',
  status: index % 2 === 0 ? 0 : 1,
}))
// export const listData = []
