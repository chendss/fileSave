<template>
  <div class="time_price_box">
    <div v-if="isShow" class="time_price_btn" @click="open">
      <img :src="TimePriceImg" />
      <span>一次性出售越多单价越高</span>
      <span class="btn">查看阶梯单价</span>
    </div>
    <Dialog
      class="time_price_dialog"
      :visible="visible"
      title="阶梯单价"
      width="470px"
      :before-close="beforeClose"
    >
      <div class="content">
        <div class="header">
          <div class="cell">
            <span>出售USDT</span>
          </div>
          <div class="cell">
            <span>特惠单价</span>
          </div>
        </div>
        <div class="detail_box">
          <div v-for="(item, index) in sellPriceConfig" :key="index" class="row">
            <div class="cell">
              <span>{{ `>=${item.miniLimit}` }}</span>
            </div>
            <div class="cell">
              <span>{{ `${item.price}` }}</span>
            </div>
          </div>
        </div>
      </div>
    </Dialog>
  </div>
</template>

<script>
import TimePriceImg from '@/assets/images/jieti_icon@2x.png'
import { Dialog } from '@/components'
export default {
  components: { Dialog },
  props: {
    sellPriceConfig: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      TimePriceImg,
      visible: false,
    }
  },
  computed: {
    isShow() {
      return this.sellPriceConfig.length >= 2
    },
  },
  methods: {
    open() {
      this.visible = true
    },
    beforeClose(done) {
      this.visible = false
      done?.()
    },
  },
}
</script>

<style lang="scss" scoped>
.time_price_box {
  width: 100%;
  padding-top: 10px;
  .time_price_btn {
    cursor: pointer;
    width: 100%;
    padding: 10px;
    background: var(--input-border-color);
    border-radius: var(--border);
    display: flex;
    align-items: center;
    justify-content: flex-start;
    img {
      width: 22px;
      height: 24px;
      margin-right: 5px;
    }
    span {
      font-size: 14px;
      color: var(--main-text-color);
      letter-spacing: 0;
      line-height: 14px;
      font-weight: 600;
    }
    .btn {
      padding: 4px 10px;
      margin-left: auto;
      font-size: 12px;
      color: var(--container-bg);
      letter-spacing: 0;
      line-height: 12px;
      font-weight: 400;
      border-radius: 12px;
      background: var(--main-text-color);
    }
  }
}
</style>

<style lang="scss">
.time_price_dialog {
  .content {
    display: flex;
    width: 100%;
    flex-direction: column;
    .header {
      width: 100%;
      display: flex;
      .cell {
        padding: 8px 22px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 112px;
        background: rgba($color: #22afc2, $alpha: 0.2);
        span {
          font-size: 14px;
          color: #22afc2;
          letter-spacing: 0;
          text-align: center;
          line-height: 14px;
          font-weight: 600;
        }
        &:last-child {
          margin-left: 1px;
          flex: 1 1 auto;
          background: rgba($color: #22afc2, $alpha: 0.1);
        }
      }
    }
    .detail_box {
      width: 100%;
      flex-direction: column;
      display: flex;
      .row {
        display: flex;
        margin-top: 1px;
        .cell {
          width: 112px;
          padding: 8px 22px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 112px;
          background: rgba($color: #ddba82, $alpha: 0.2);
          span {
            color: #ddba82;
          }
          &:last-child {
            margin-left: 1px;
            flex: 1 1 auto;
            background: rgba($color: #ddba82, $alpha: 0.1);
          }
        }
      }
    }
  }
}
</style>
