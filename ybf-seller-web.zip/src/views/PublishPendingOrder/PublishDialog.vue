<template>
  <Dialog
    title="确认发布"
    :visible="visible"
    width="470px"
    :before-close="beforeClose"
    class="publish_dialog"
  >
    <Titps text="发布后将不能修改，只能进行下架重新发布。请仔细核对以下信息" />
    <Form class="form_box">
      <FormItem label="类型">
        <span>{{ getTableEnumValue(data, 'type', enumType, 'typeSelect') }}</span>
      </FormItem>
      <FormItem label="交易对">
        <span>{{ getTableEnumValue(data, 'pair', enumType, 'pairSelect') }}</span>
      </FormItem>
      <FormItem label="出售数量">
        <span>{{ formatNumber(data.number, 'USDT', undefined, false) }}</span>
      </FormItem>
      <FormItem label="收款方式" class="hight_form_item">
        <div class="payMethod_box_parent">
          <div v-for="item of payMethod" :key="item.id" class="payMethod_box">
            <img :src="payImgTypeMap[`${item.payMethodType}`]" />
            <span>{{ payMethodMap[`${item.payMethodType}`] }}</span>
            <span class="card_code">{{ `（${item.account}）` }}</span>
          </div>
        </div>
      </FormItem>
      <FormItem label="预计获得" class="hight_form_item">
        <InputPlus class="will_get_box" :value="data.willGet" readonly>
          <template slot="prefix">
            <span class="will_prefix">￥</span>
          </template>
        </InputPlus>
      </FormItem>
      <FormItem label="交易密码" class="hight_form_item">
        <PasswordInput v-model="password" :error="passwordError" @errorChange="errorChange" />
      </FormItem>
    </Form>
    <div class="footer">
      <Button :disabled="password.length !== 6" :loading="loading" @click="confirmPublish">确定发布</Button>
    </div>
  </Dialog>
</template>

<script>
import { PendingOrder, User } from '@/api'
import { Dialog, Button, Form, InputPlus, FormItem, Titps, PasswordInput } from '@/components'
import { payMethodMap, payImgTypeMap } from '@/utils/mapData'
import { publishPendingOrderType } from '@/utils/mapData'
import { pairSelect } from './const'
import { get, transSelectOptionsToObj } from '@/utils/tools'
import { getTableEnumValue } from '@/utils/table'
import { formatNumber } from '@/utils/mathe'
export default {
  components: { Dialog, Button, Form, InputPlus, FormItem, Titps, PasswordInput },
  props: {
    visible: {
      type: Boolean,
      default: () => false,
    },
    data: {
      type: Object,
      default: () => ({}),
    },
  },
  data() {
    return {
      loading: false,
      passwordError: false,
      password: '',
      payImgTypeMap,
      payMethodMap,
      enumType: transSelectOptionsToObj({
        typeSelect: publishPendingOrderType,
        pairSelect,
      }),
    }
  },
  computed: {
    payMethod() {
      const result = []
      for (const key of Object.keys(this.data.payMethod || {})) {
        let item = this.data.payMethod[key]
        item = item instanceof Array ? item : [item]
        result.push(...item)
      }
      return result
    },
    publishParams() {
      const [coinType, currencyType] = get(this.data, 'pair', '1:-1').split(':')
      const orderPendingCreateType = get(this.data, 'type', '4')
      const result = {
        currencyType: +currencyType,
        coinType: +coinType,
        accordanceWith: 0,
        digitalCurrencyAmount: get(this.data, 'number', '0'),
        paymentType: this.payMethod.reduce((pre, item) => {
          const { payMethodType } = item
          if (pre[payMethodType]) {
            pre[payMethodType].push(+item.id)
          } else {
            pre[payMethodType] = [+item.id]
          }
          return pre
        }, {}),
        list: [
          {
            blurTarget: '',
            usageType: 21,
            verifyCode: this.password,
            verifyCodeType: 4,
          },
        ],
        orderPendingCreateType: +orderPendingCreateType,
      }
      return result
    },
  },
  watch: {
    visible() {
      Object.assign(this.$data, this.$options.data())
    },
  },
  mounted() {},
  methods: {
    get,
    getTableEnumValue,
    formatNumber,
    beforeClose(done) {
      this.$emit('close')
      done?.()
    },
    async confirmPublish() {
      try {
        this.loading = true
        const res = await PendingOrder.publishPendingOrder(this.publishParams)
        if (get(res, 'code', '') === '4325') {
          this.passwordError = true
          this.password = ''
        } else {
          this.$router.push({ path: '/PendingOrder' })
          this.beforeClose()
        }
      } catch (error) {
        console.error('发生异常 confirmPublish', error)
      } finally {
        this.loading = false
      }
    },
    errorChange(val) {
      this.passwordError = val
    },
  },
}
</script>

<style lang="scss" scoped>
.publish_dialog {
  .payMethod_box_parent {
    display: inline-flex;
    background: var(--main-bg);
    border: 1px solid rgba(58, 57, 56, 1);
    border-radius: var(--border);
    padding: 12px 10px;
    align-items: center;
    flex-direction: column;
  }
  .payMethod_box {
    display: inline-flex;
    align-items: center;
    img {
      width: 18px;
      height: 18px;
      margin-right: 5px;
    }
    span {
      font-size: 14px;
      color: var(--main-text-color);
      letter-spacing: 0;
      line-height: 14px;
      font-weight: 400;
      &.card_code {
        font-weight: 700;
      }
    }
  }
  .payMethod_box + .payMethod_box {
    margin-top: 5px;
  }
  .will_get_box {
    ::v-deep {
      .el-input__prefix {
        color: #22afc2;
      }
      input {
        color: #22afc2;
      }
    }
  }
  ::v-deep {
    .el-dialog__body {
      padding: 20px !important;
      .custom_form {
        .hight_form_item {
          .el-form-item__label {
            height: 40px;
            min-height: 40px;
          }
          .el-form-item__content {
            height: 40px;
            min-height: 40px;
          }
        }
        .el-form-item__label {
          width: 56px;
          margin-right: 10px;
          height: 14px;
          min-height: 14px;
        }
        .el-form-item__content {
          height: 14px;
          width: calc(100% - 66px);
          min-height: 14px;
          > span {
            display: flex;
            align-items: center;
            height: 100%;
            font-size: 14px;
            color: var(--main-text-color);
            letter-spacing: 0;
            line-height: 14px;
            font-weight: 400;
          }
        }
        .custom_form_item + .custom_form_item {
          margin-top: 20px;
        }
      }
    }
    .titps_box {
      width: 100%;
      margin-bottom: 20px;
    }
  }
  .footer {
    display: flex;
    padding-left: 66px;
    padding-top: 30px;
    ::v-deep {
      .custom_button {
        width: 100% !important;
      }
    }
  }
}
</style>
