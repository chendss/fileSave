<template>
  <Page id="id-publish-pending-order">
    <template v-if="!maintenance">
      <Form :model="form" :rules="rules">
        <FormItem label="类型">
          <Select v-model="form.type" :options="typeSelect" type="flat" />
        </FormItem>
        <FormItem label="交易对">
          <Select v-model="form.pair" :options="pairSelect" type="flat" />
        </FormItem>
        <FormItem label="出售数量">
          <template slot="placeholder">
            <div class="placeholder_box">
              <span class="text">单笔出售限额：</span>
              <span class="number">{{ currentSellPriceMap.min }}-{{ currentSellPriceMap.max }} USDT</span>
            </div>
            <TimePrice :sellPriceConfig="sellPriceConfig" />
          </template>
          <template slot="rightPlaceholder">
            <div class="right_placeholder_box">
              <span class="text">您的可用余额</span>
              <span class="number">{{ balance }} USDT</span>
            </div>
          </template>
          <InputPlus v-model="form.number" class="number_input" valueType="number" coin="USDT" min="0">
            <template slot="suffix">
              <div class="number_suffix">
                <span @click="all">全部</span>
                <span class="symbol">USDT</span>
                <img :src="USDTImg" />
              </div>
            </template>
          </InputPlus>
        </FormItem>
        <FormItem label="报价模式">
          <Radio v-model="form.priceModel" text="浮动报价" readonly>
            <div class="model_box">
              <span>（当前</span>
              <span class="number">{{ `￥${currentPrice}` }} / USDT</span>
              <span>）</span>
            </div>
          </Radio>
        </FormItem>
        <FormItem label="收款方式">
          <PaymentMethod v-model="form.paymentMethod" @chose="chosePayMethod" />
        </FormItem>
        <FormItem label="预计获得">
          <InputPlus
            :value="willGet"
            :class="{ will_get_box: true, hasContent: Number(willGet) }"
            placeholder="0.00"
            readonly
          >
            <template slot="prefix">
              <span class="will_prefix">￥</span>
            </template>
          </InputPlus>
        </FormItem>
        <FormItem label="特惠出售须知">
          <div class="written_consent">
            <span v-for="(text, index) in writtenConsent" :key="text">{{ `${index + 1}，${text}` }}</span>
          </div>
        </FormItem>
      </Form>
      <div class="footer">
        <Check v-model="checked" text="我已知晓，并同意挂单出售" class="check_submit" />
        <Button :disabled="checkButton" :loading="publishLoading" @click="publish">发布挂单出售</Button>
      </div>
      <PublishDialog ref="publishDialog" :visible="visible" :data="currentData" @close="publishDialogClose" />
    </template>
    <div v-else class="error_pending_order">
      <img :src="Restriction" />
      <span>{{ maintenance }}</span>
    </div>
  </Page>
</template>

<script>
import { Message } from 'element-ui'
import TimePrice from './TimePrice.vue'
import { User, PendingOrder } from '@/api'
import PublishDialog from './PublishDialog.vue'
import { formatNumber, times, comparedTo } from '@/utils/mathe'
import USDTImg from '@/assets/images/USDT@2x.png'
import { publishPendingOrderType } from '@/utils/mapData'
import Restriction from '@/assets/images/xianzhi@2x.png'
import { pairSelect, writtenConsent } from './const'
import { Select, Button, Page, Form, FormItem, InputPlus, Radio, Check, PaymentMethod } from '@/components'
import BigNumber from 'bignumber.js'

export default {
  components: {
    Select,
    Page,
    Button,
    Form,
    FormItem,
    InputPlus,
    Radio,
    Check,
    PaymentMethod,
    PublishDialog,
    TimePrice,
  },
  data() {
    return {
      Restriction,
      USDTImg,
      typeSelect: publishPendingOrderType,
      checked: false,
      visible: false,
      pairSelect,
      balance: 0,
      writtenConsent,
      publishLoading: false,
      prePrice: '',
      closePreferentialOpenMsg: '',
      closeOtcSellMaintain: '',
      checkTradeOrderSellPredict: '',
      form: {
        type: '5',
        pair: '1:-1',
        number: '',
        priceModel: true,
        paymentMethod: [],
      },
      sellPriceConfig: [],
      rules: {},
      currentPayMethod: {},
      timerMap: {
        balance: Math.random(),
        sellPrice: Math.random(),
        otcConfig: Math.random(),
      },
    }
  },
  computed: {
    maintenance() {
      const msg =
        this.closePreferentialOpenMsg || this.closeOtcSellMaintain || this.checkTradeOrderSellPredict
      return msg
    },
    checkButton() {
      const number = this.form.number
      if (number !== '' && number != null) {
        if (
          comparedTo(number, this.currentSellPriceMap.max, false) ||
          comparedTo(this.currentSellPriceMap.min, number, false)
        ) {
          return true
        }
      }
      if (this.checked && !!this.form.number && this.form.paymentMethod.length > 0) {
        return false
      }
      return true
    },
    willGet() {
      try {
        const { number } = this.form
        const result = times(number, this.currentPrice)
        if (`${result}` === 'NaN') {
          return '0.00'
        }
        return formatNumber(result, 'CNY', undefined, false)
      } catch (error) {
        return '0.00'
      }
    },
    currentData() {
      return {
        ...this.form,
        willGet: this.willGet,
        payMethod: this.currentPayMethod,
      }
    },
    currentPrice() {
      return `${this.currentSellPriceMap.price}`
    },
    currentSellPriceMap() {
      let min = '9999999999999999'
      let max = '0'
      let price = this.prePrice
      let maxPrice = '0'
      const { number } = this.form
      const n = number === '' ? '0' : number
      if (this.sellPriceConfig.length < 1) {
        return { price: '0', min: '0', max: '0' }
      }
      for (const item of this.sellPriceConfig) {
        if (comparedTo(min, item.miniLimit)) {
          min = item.miniLimit
        }
        if (comparedTo(item.price, maxPrice)) {
          maxPrice = item.price
        }
        if (comparedTo(item.maxLimit, max)) {
          max = item.maxLimit
        }
        if (comparedTo(n, item.miniLimit) && comparedTo(item.maxLimit, n)) {
          price = item.price
        }
      }
      const currentPrice = price || maxPrice
      this.setPrePrice(currentPrice)
      return { price: currentPrice, min, max }
    },
  },
  destroyed() {
    const values = Object.values(this.timerMap)
    values.forEach((v) => clearTimeout(v))
  },
  mounted() {
    this.refreshBalance()
    this.refreshSellPrice()
    this.refreshConfig()
    this.checkPreferentialOpen()
  },
  methods: {
    async checkPreferentialOpen() {
      const msg = await PendingOrder.checkPreferentialOpen()
      this.closePreferentialOpenMsg = msg
    },
    async refreshConfig() {
      const that = this
      const res = await PendingOrder.checkOtcSellMaintain()
      this.closeOtcSellMaintain = res
      this.timerMap.otcConfig = setTimeout(() => {
        that.refreshConfig()
      }, 2000)
    },
    setPrePrice(price) {
      this.prePrice = price
    },
    async refreshBalance() {
      const that = this
      const res = await User.getFetchBalance()
      if (res) {
        const { availableAmount } = res
        this.balance = availableAmount
      }
      this.timerMap.balance = setTimeout(() => {
        that.refreshBalance()
      }, 2000)
    },
    async refreshSellPrice() {
      const that = this
      const res = await PendingOrder.getPreferentialSellPrice()
      if (res instanceof Array) {
        this.sellPriceConfig = res
      }
      this.timerMap.sellPrice = setTimeout(() => {
        that.refreshSellPrice()
      }, 2000)
    },
    async publish() {
      let msg = ''
      this.publishLoading = true
      const list = [
        PendingOrder.checkPreferentialOpen(),
        PendingOrder.checkTradeOrderSellPredict(this.form.number),
      ]
      const [closePreferentialOpenMsg, checkTradeOrderSellPredict] = await Promise.all(list)
      if (closePreferentialOpenMsg || checkTradeOrderSellPredict) {
        msg = closePreferentialOpenMsg || checkTradeOrderSellPredict
      }
      if (msg) {
        Message.error(msg)
        this.closePreferentialOpenMsg = closePreferentialOpenMsg
        this.checkTradeOrderSellPredict = checkTradeOrderSellPredict
        this.publishLoading = false
        return
      }
      const publishDialogRef = this.$refs['publishDialog']
      if (publishDialogRef) {
        try {
          this.publishLoading = true
          const params = { ...publishDialogRef.publishParams }
          delete params.list
          const res = await PendingOrder.checkPublishPendingOrder(params)
          const { innerMatchUser, openAppSellCommission } = res || {}
          if (res == null) {
            return
          }
          this.visible = true
        } catch (error) {
          console.log('publish预检查失败', error)
        } finally {
          this.publishLoading = false
        }
      }
    },
    all() {
      this.form.number = formatNumber(
        BigNumber.min(`${this.balance}`, this.currentSellPriceMap.max).toString(),
        'USDT'
      )
    },
    chosePayMethod(list) {
      this.currentPayMethod = list
    },
    publishDialogClose() {
      this.visible = false
    },
  },
}
</script>

<style lang="scss" scoped>
#id-publish-pending-order {
  padding-top: 40px;
  flex-direction: column;
  padding-bottom: 104px;

  .error_pending_order {
    margin-top: 0px;
    padding: 24px 20px;
    height: 70px;
    background: #242322;
    border: 1px solid rgba(58, 57, 56, 1);
    border-radius: 7px;
    display: flex;
    align-items: center;
    img {
      width: 24px;
      height: 24px;
      margin-right: 6px;
    }
    span {
      display: inline-flex;
      font-size: 14px;
      color: #ff6060;
      letter-spacing: 0;
      line-height: 14px;
      font-weight: 600;
    }
  }

  .right_placeholder_box {
    display: inline-flex;
    flex-direction: column;
    .text {
      font-weight: 400;
    }
    .number {
      font-weight: 700;
      margin-top: 4px;
      color: var(--main-text-color);
    }
  }
  .written_consent {
    display: inline-flex;
    flex-direction: column;
    background: var(--main-bg);
    border: 1px solid var(--split-border-color);
    border-radius: var(--border);
    padding: 14px 20px;
    span {
      font-size: 12px;
      color: var(--sub-text-color);
      letter-spacing: 0;
      line-height: 20px;
      font-weight: 400;
    }
  }
  .model_box {
    span {
      font-size: 14px;
      color: #22afc2;
    }
    .number {
      font-weight: 700;
    }
  }
  .placeholder_box {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    max-height: 100%;
    overflow: hidden;
  }
  .will_get_box {
    &.hasContent {
      ::v-deep {
        .el-input__prefix {
          color: #22afc2;
        }
        input {
          color: #22afc2;
        }
      }
    }
    ::v-deep {
      input {
        color: var(--sub-text-color);
      }
    }
  }
  .number_input {
    ::v-deep {
      input {
        padding-right: 108px !important;
      }
    }
  }
  .number_suffix {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding-right: 10px;
    img {
      width: 16px;
      height: 16px;
    }
    span {
      font-size: 12px;
      letter-spacing: 0;
      line-height: 12px;
      font-weight: 400;
      color: #ddba82;
      &:first-child {
        cursor: pointer;
      }
      &.symbol {
        margin: 0 6px 0 10px;
        color: var(--sub-text-color);
      }
    }
  }
  .will_prefix {
    font-size: 14px;
  }
  .will_get_placeholder_box {
    .text {
      font-weight: 400;
    }
    .number {
      font-weight: 700;
    }
  }
  .footer {
    display: flex;
    flex-direction: column;
    width: 375px;
    margin-top: 26px;
    margin-left: 224px;
    ::v-deep {
      .custom_check {
        margin-bottom: 26px;
      }
    }
  }
}
</style>
