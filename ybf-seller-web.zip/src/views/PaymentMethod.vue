<template>
  <div>
    <div id="id-div-body">
      收款方式
    </div>
  </div>
</template>

<script>

export default {
  computed: {
  },
  methods: {
  }
}

</script>
<style lang="scss" scoped>
</style>
