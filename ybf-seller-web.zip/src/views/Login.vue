<template>
  <div class="login f-xcc text-white text-center">
    <div class="login-form f-ycc">
      <div class="title fs-18 mb-25">扫码登录</div>
      <div class="qrcode-box mb-40">
        <img :src="qrcode" alt="" class="qrcode" />
        <img src="@/assets/images/icon.png" alt="" class="logo" />
        <div v-if="refreshShow" class="refresh f-ycc">
          <img
            src="@/assets/images/refresh_gray@2x.png"
            alt=""
            class="mb-15 refresh_gray cursor"
            @click="getQrCodeId"
          />
          <div class="fs-14 text-gray">二维码已过期</div>
        </div>
      </div>
      <div class="login-tip fs-16 mb-10">请使用手机易币付APP扫码</div>
      <div class="login-tip text-primary cursor fs-14" @click="openDownload">下载易币付APP</div>
      <div v-if="loading" class="logining f-ycc text-primary">
        <img src="@/assets/images/loading_full.png" alt="" class="mb-10 loading_full" />
        <div>扫码成功，正在登录……</div>
      </div>
    </div>
  </div>
</template>

<script>
import QRCode from 'qrcode'
import UAParser from 'ua-parser-js'
import FingerprintJS from '@fingerprintjs/fingerprintjs'
import { getQrCodeId, getQrCodeState, fetchDownloadUrl, logout } from '@/api/login.js'
import { setToken, getToken, removeToken } from '@/utils/auth'
let timers = [] // 以免内存泄露
export default {
  name: 'Login',
  data() {
    return {
      loading: false,
      refreshShow: false,
      qrcode: '',
      qrCodeId: '',
      tempToken: '',
      qrCodeStr: '',
      STATUS_ENUM: {
        2: 'COMFIRM_AUTH', // 确定授权
        3: 'INVALID', // 非法
        1: 'STAY_AUTH', // 等待授权
        0: 'STAY_SCAN', // 等待扫码
      },

      downloadUrl: null,
    }
  },
  async created() {
    let oldToken = getToken()
    if (oldToken) {
      await logout()
    }
    this.getQrCodeId()
    this.fetchDownloadUrl()
  },
  beforeDestroy() {
    this.clearTimers()
  },
  methods: {
    clearTimers() {
      while (timers.length - 1 >= 0) {
        let index = timers.length - 1
        let timer = timers[index]
        clearInterval(timer)
        timer = null
        timers.splice(index, 1)
      }
    },
    async fetchDownloadUrl() {
      try {
        const { data } = await fetchDownloadUrl()
        this.downloadUrl = data.ybf
      } catch (error) {
        console.log(error)
      }
    },
    openDownload() {
      window.open(this.downloadUrl, 'blank')
    },
    async getQrCodeState() {
      try {
        let { data } = await getQrCodeState({
          qrCodeId: this.qrCodeId,
          tempToken: this.tempToken,
        })
        let { token, status } = data
        if (this.STATUS_ENUM[status] === 'STAY_AUTH') {
          this.loading = true
        } else if (this.STATUS_ENUM[status] === 'INVALID') {
          this.refreshShow = true
          this.loading = false
          this.clearTimers()
        } else if (this.STATUS_ENUM[status] === 'COMFIRM_AUTH') {
          let oldToken = getToken()
          if (oldToken) {
            await logout()
            removeToken()
          }
          setToken(token)
          this.loading = false
          this.clearTimers()
          this.$router.push('/')
        }
      } catch (error) {
        this.clearTimers()
        console.log(error)
      }
    },
    async getQrCodeId() {
      try {
        this.refreshShow = false
        let { data } = await getQrCodeId()
        let result = await FingerprintJS.load().then((fp) => fp.get())
        this.qrCodeId = data.qrCodeId
        this.tempToken = data.tempToken
        const deviceId = result.visitorId
        let parser = new UAParser().getResult()
        let agentName = `${parser?.browser?.name}/${parser?.os?.name} special`
        this.qrCodeStr = `ybf://weblogin?qrCodeId=${this.qrCodeId}&agentName=${agentName}&webDeviceId=${deviceId}`
        QRCode.toDataURL(this.qrCodeStr, { margin: 2 }, (err, url) => {
          console.log(url, err)
          this.qrcode = url
          timers.push(setInterval(this.getQrCodeState, 2000))
        })
      } catch (error) {
        return Promise.reject(error)
      }
    },
  },
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.login {
  height: 100%;

  .title {
    width: 106px;
    background: #2d2c2b;
    border-radius: 7px;
    padding: 10px 0;
  }
}
.login-form {
  position: relative;
  .qrcode-box {
    position: relative;
    width: 162px;
    height: 162px;
    border-radius: 7px;
    overflow: hidden;
    .qrcode {
      width: 100%;
      height: 100%;
    }
    .logo {
      width: 40px;
      height: 40px;
      position: absolute;
      left: 50%;
      top: 50%;
      transform: translate(-50%, -50%);
    }
    .refresh {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba($color: #000000, $alpha: 0.8);
      z-index: 1000;
      .refresh_gray {
        width: 22px;
        height: 22px;
      }
    }
  }

  .logining {
    position: absolute;
    width: 100%;
    height: 100%;
    background-color: rgba($color: #000000, $alpha: 0.8);
    z-index: 1000;
    .loading_full {
      width: 26px;
      height: 26px;
      rotate: 360deg;
      animation: spin 1s steps(8) infinite;
    }
  }
}

@keyframes spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}
</style>
