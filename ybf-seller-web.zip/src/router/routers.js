import Vue from 'vue'
import VueRouter from 'vue-router'
import { constantRouterMap } from './map.js'

Vue.use(VueRouter)

export default new VueRouter({
  mode: 'hash',
  // mode: 'history',
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRouterMap
})
