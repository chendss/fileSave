
const dashboardRouter = {
  component: () => import('../views/Home.vue'),
  hidden: false,
  name: 'HomeIndex',
  path: 'dashboard',
  meta: {
    title: '主页',
    icon: 'index',
    affix: true,
    noCache: true
  }
}

const PendingOrders = [{
  component: () => import('../views/PendingOrders'),
  hidden: false,
  name: '我的挂单',
  path: 'PendingOrder',
  meta: {
    title: '我的挂单',
    icon: 'index',
    affix: true,
    noCache: true
  }
}]

const PendingOrderQuery = [{
  component: () => import('../views/PendingOrderQuery'),
  hidden: true,
  name: '我的挂单-查看',
  path: 'PendingOrderQuery',
  meta: {
    title: '我的挂单-查看',
    icon: 'index',
    affix: true,
    noCache: true
  }
}]
const PendingOrderPublish = [{
  component: () => import('../views/PublishPendingOrder'),
  hidden: true,
  name: '发布特惠出售订单',
  path: 'PublishPendingOrder',
  meta: {
    title: '发布特惠出售订单',
    icon: 'index',
    affix: true,
    noCache: true
  }
}]

const Orders = [{
  component: () => import('../views/Orders.vue'),
  hidden: false,
  name: '我的订单',
  path: 'Orders',
  meta: {
    title: '我的订单',
    icon: 'index',
    affix: true,
    noCache: true
  }
}]
const PaymentMethod = [{
  component: () => import('../views/PaymentMethod.vue'),
  hidden: false,
  name: '收款方式',
  path: 'PaymentMethod',
  meta: {
    title: '收款方式',
    icon: 'index',
    affix: true,
    noCache: true
  }
}]
const Reward = [{
  component: () => import('../views/Reward'),
  hidden: false,
  name: '我的奖励',
  path: 'Reward',
  meta: {
    title: '我的奖励',
    icon: 'index',
    affix: true,
    noCache: true
  }
}]

export const constantRouterMap = [
  {
    path: '/login',
    meta: { title: '登录', noCache: true },
    component: () => import('../views/Login.vue'),
    hidden: true
  },
  {
    path: '/404',
    component: () => import('../views/features/404.vue'),
    hidden: true
  },
  {
    // 手机禁止访问
    path: '/404-no-mobile',
    component: () => import('../views/features/Page404NoMobile.vue'),
    hidden: true
  },
  {
    path: '/401',
    component: () => import('../views/features/401.vue'),
    hidden: true
  },
  {
    // 维护中页面
    path: '/maintenance',
    component: () => import('../views/features/Maintenance.vue'),
    hidden: true
  },
  {
    path: '/redirect',
    component: () => import('../layout/index.vue'),
    hidden: true,
    children: [
      {
        path: '/redirect/:path*',
        component: () => import('../views/features/redirect.vue')
      }
    ]
  },
  {
    alwaysShow: false,
    children: [dashboardRouter, ...PendingOrders, ...Orders, ...PaymentMethod, ...Reward, ...PendingOrderQuery, ...PendingOrderPublish],
    component: () => import('../layout/index.vue'),
    hidden: false,
    name: '主页',
    path: '/',
    redirect: '/dashboard',
    meta: {
      title: '主页',
      icon: 'index',
      affix: true,
      noCache: true
    }
  }

]
