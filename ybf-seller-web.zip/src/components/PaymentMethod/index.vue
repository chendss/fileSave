<template>
  <div v-loading="loading" class="payment_method_box">
    <div class="payment_method_box_content">
      <template v-if="data.length <= 0">
        <div class="placeholder">
          <span>注：目前仅能匹配到银行卡订单，请添加您的银行卡收款方式</span>
        </div>
        <div class="split_border" />
      </template>
      <div v-else class="content">
        <div class="success_box">
          <div v-for="(item, index) in successPaymentMethod" :key="index" class="item">
            <img :src="payImgTypeMap[`${item.payMethodType}`]" />
            <span>{{ payMethodMap[`${item.payMethodType}`] }}</span>
            <span class="card_code">{{ `（${item.account}）` }}</span>
            <CheckIcon v-model="checkMap[item.id]" class="check_icon" @click="chosePayMethod(item)" />
          </div>
        </div>
        <div v-if="errorPaymentMethod.length > 0" class="error_box">
          <span class="description">以下暂不可用</span>
          <div v-for="(item, index) in errorPaymentMethod" :key="index" class="item">
            <div class="item_content">
              <img :src="payImgTypeMap[`${item.payMethodType}`]" />
              <span>{{ payMethodMap[`${item.payMethodType}`] }}</span>
              <span class="card_code">{{ `（${item.account}）` }}</span>
            </div>
            <span class="error_message">{{ item.errorMessage }}</span>
          </div>
        </div>
      </div>
      <div class="footer">
        <div class="plus_box">
          <span class="plus" />
          <span>新增收款方式</span>
        </div>
        <div class="refresh_box" @click="getPayMethodData">
          <img :src="Refresh" />
          <span>刷新</span>
        </div>
      </div>
    </div>
    <Titps v-if="!loading" class="titps_payment" text="每类收款方式只能选择一个" type="normal" />
  </div>
</template>

<script>
import { PendingOrder } from '@/api'
import Refresh from '@/assets/images/refresh_yellow@2x.png'
import { payImgTypeMap, payMethodMap } from '@/utils/mapData'
import { Titps } from '@/components'
import { CheckIcon } from '@/components/Icon'
export default {
  components: { CheckIcon, Titps },
  model: {
    prop: 'value',
    event: 'change',
  },
  props: {
    value: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      loading: false,
      data: [],
      Refresh,
      payMethodMap,
      payImgTypeMap,
      checkMap: {},
    }
  },
  computed: {
    successPaymentMethod() {
      const list = this.data.filter((d) => !d.isError)
      const map = this.payMethodMap
      return list.map((item) => {
        return {
          ...item,
          typeStr: map[item.type],
        }
      })
    },
    errorPaymentMethod() {
      const list = this.data.filter((d) => d.isError)
      const map = this.payMethodMap
      return list.map((item) => {
        return {
          ...item,
          typeStr: map[item.type],
        }
      })
    },
  },
  watch: {
    value(list) {
      const result = {}
      for (const item of list) {
        const { key, type } = item
        result[key] = true
      }
      this.checkMap = { ...this.checkMap, ...result }
    },
  },
  mounted() {
    this.init()
  },
  methods: {
    async init() {
      this.constructCheckMap()
      return this.getPayMethodData()
    },
    constructCheckMap() {
      try {
        const result = {}
        for (const item of this.value) {
          const { key, type } = item
          result[key] = true
        }
        return { ...this.checkMap, ...result }
      } catch (error) {
        console.log('构建失败', error)
        return {}
      }
    },
    async getPayMethodData() {
      try {
        this.loading = true
        this.data = await PendingOrder.getPayMethods()
        this.checkMap = this.data.reduce((pre, item) => {
          pre[item.id] = false
          return pre
        }, {})
      } catch (error) {
        console.log('getPayMethodData error ', error)
      } finally {
        this.loading = false
      }
    },
    getDataItemById(id) {
      for (const item of this.data) {
        if (`${item.id}` === `${id}`) {
          return item
        }
      }
      return {}
    },
    chosePayMethod(item) {
      const currentItem = item
      const result = { ...this.checkMap }
      for (const item of Object.entries(this.checkMap)) {
        const [key, value] = item
        if (value) {
          const dataItem = this.getDataItemById(key)
          if (dataItem.payMethodType === currentItem.payMethodType) {
            result[key] = false
            result[currentItem.id] = true
          }
        } else {
          result[key] = value
        }
      }
      this.checkMap = { ...result }
      const list = Object.entries(result)
        .filter((item) => item[1])
        .map((item) => ({ key: item[0], payMethodType: this.getDataItemById(item[0]).payMethodType }))
      this.$emit('change', list)
      console.log('this.checkMap ', this.checkMap)
      const currentItems = Object.keys(this.checkMap).reduce((pre, key) => {
        const item = this.checkMap[key]
        if (item) {
          if (pre[key]) {
            const list = pre[key] instanceof Array ? pre[key] : [pre[key]]
            pre[key] = [...list, this.getDataItemById(key)]
          } else {
            pre[key] = [this.getDataItemById(key)]
          }
        }
        return pre
      }, {})
      this.$emit('chose', currentItems)
    },
  },
}
</script>

<style lang="scss" scoped>
.payment_method_box {
  display: flex;
  flex-direction: column;
  padding-top: 0;
  overflow: hidden;
  .payment_method_box_content {
    padding: 20px;
    padding-top: 0;
    background: var(--main-bg);
    border-radius: var(--border);
  }
  .placeholder {
    display: flex;
    flex-direction: column;
    padding-bottom: 20px;
    padding-top: 20px;
    span {
      font-size: 12px;
      color: #888683;
      letter-spacing: 0;
      line-height: 12px;
      font-weight: 400;
    }
  }
  .footer {
    display: flex;
    padding: 20px 0;
    padding-bottom: 0;
    align-items: center;
    justify-content: flex-start;
    .plus_box {
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }
    .plus {
      margin-right: 6px;
      transform-origin: center;
      width: 9px;
      height: 9px;
      display: inline-flex;
      position: relative;
      overflow: hidden;
      transform-origin: center;
      &::after,
      &::before {
        z-index: 999;
        position: absolute;
        content: '';
        left: 50%;
        top: 0;
        bottom: 0;
        right: 0;
        margin: auto;
        transform-origin: center;
      }
      &::after {
        transform: translate(-50%, 0) rotate(90deg);
        width: 100px;
        height: 1px;
        background: var(--main-text-color);
      }
      &::before {
        transform: translate(-50%, 0) rotate(0deg);
        width: 100px;
        height: 1px;
        background: var(--main-text-color);
      }
    }
    span {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-size: 14px;
      color: var(--main-text-color);
      letter-spacing: 0;
      line-height: 14px;
      font-weight: 400;
    }
    .refresh_box {
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      margin-left: auto;
      img {
        width: 12px;
        height: 12px;
        margin-right: 4px;
      }
    }
  }

  .content {
    display: flex;
    flex-direction: column;
    .item {
      padding: 16px 0;
      display: flex;
      align-items: center;
      justify-content: flex-start;
      width: 100%;
      display: flex;
      align-items: center;
      position: relative;
      color: var(--main-text-color);
      &::after {
        content: '';
        position: absolute;
        left: 0;
        bottom: 0;
        right: 0;
        height: 1px;
        background: var(--split-border-color);
      }
      img {
        width: 18px;
        height: 18px;
        margin-right: 6px;
      }
      span {
        white-space: nowrap;
        font-size: 14px;
        color: var(--main-text-color);
        letter-spacing: 0;
        line-height: 14px;
        font-weight: 400;
        &.card_code {
          text-overflow: ellipsis;
          max-width: 240px;
          overflow: hidden;
        }
      }
      .check_icon {
        margin-left: auto;
        margin-right: 0;
      }
      .split_border {
        margin-top: 0;
      }
    }
    .success_box {
      display: flex;
      flex-direction: column;
    }
    .error_box {
      pointer-events: none;
      display: flex;
      flex-direction: column;
      * {
        pointer-events: none;
        color: #4b4845 !important;
      }
      img {
        opacity: 0.5;
      }
      .description {
        margin-top: 16px;
        margin-bottom: 1px;
        font-size: 16px;
        color: #4b4845;
        letter-spacing: 0;
        line-height: 15px;
        font-weight: 400;
      }
      .item {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        .item_content {
          width: 100%;
          display: flex;
          align-items: center;
        }
        .error_message {
          margin-top: 10px;
          display: inline-flex;
          margin-left: 22px;
          font-size: 12px;
          letter-spacing: 0;
          line-height: 13px;
          font-weight: 400;
        }
      }
    }
  }
  .titps_payment {
    padding: 10px 0;
    ::v-deep {
      span {
        color: var(--sub-text-color);
      }
    }
  }
}
</style>
