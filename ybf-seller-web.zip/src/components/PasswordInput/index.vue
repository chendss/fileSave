<template>
  <div :class="{ password_box: true, error }">
    <div class="password_show">
      <div
        v-for="index in 6"
        :key="index"
        :class="{ password_item: true, hasValue: password.length > index - 1 }"
      />
    </div>
    <form action="">
      <input
        ref="input"
        v-model="password"
        class="password_input"
        type="password"
        @blur="blur"
        @focus="focus"
        @input="change"
      />
    </form>
  </div>
</template>

<script>
import { get } from '@/utils/tools'
export default {
  model: {
    prop: 'value',
    event: 'change',
  },
  props: {
    value: {
      type: String,
      default: () => '',
    },
    error: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      password: '',
    }
  },
  watch: {
    value(val) {
      this.password = val
    },
    error(val) {
      if (val === true) {
        this.$emit('change', '')
      }
    },
  },
  mounted() {
    this.password = this.value
  },
  methods: {
    blur() {},
    focus() {},
    change(event) {
      if (this.error) {
        this.$emit('errorChange', false)
      }
      const val = Array.from(get(event, 'target.value', '')).slice(0, 6).join('')
      this.$emit('change', val)
    },
  },
}
</script>

<style lang="scss" scoped>
.password_box {
  display: flex;
  width: 100%;
  height: 40px;
  &.error {
    .password_show {
      .password_item {
        border: 1px solid rgba(255, 96, 96, 1) !important;
      }
    }
  }
  .password_show {
    height: 40px;
    display: flex;
    height: 100%;
    .password_item {
      position: relative;
      &.hasValue {
        border: 1px solid var(--main-text-color);
        &::after {
          position: absolute;
          content: '';
          left: 0;
          top: 0;
          bottom: 0;
          right: 0;
          margin: auto;
          border-radius: 100%;
          width: 10px;
          height: 10px;
          background: var(--main-text-color);
        }
      }
      border: 1px solid rgba(136, 134, 131, 1);
      width: 40px;
      height: 40px;
      border-radius: var(--border);
    }
    .password_item + .password_item {
      margin-left: 25px;
    }
  }
  form {
    height: 100%;
    z-index: 22;
    position: absolute;
    opacity: 0;
    width: 100%;
    input {
      font-size: 1px;
      height: 100%;
      width: 100%;
      text-size-adjust: none;
    }
  }
}
</style>
