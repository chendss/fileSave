<template>
  <el-button
    v-if="btnType !== 'text'"
    :class="{ custom_button: true, normal: btnType === 'normal', content_empty: contentStyle === 'empty' }"
    v-bind="$attrs"
    v-on="$listeners"
  >
    <slot />
  </el-button>
  <span v-else class="custom_button btn_text" v-bind="$attrs" v-on="$listeners"><slot /></span>
</template>

<script>
export default {
  props: {
    btnType: {
      type: String,
      default: 'normal',
    },
    contentStyle: {
      type: String,
      default: 'normal',
    },
  },
  computed: {},
}
</script>

<style lang="scss" scoped>
.custom_button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 12px 18px;
  border-radius: var(--border);
  background: var(--main-text-color);
  border: 1px solid var(--main-text-color);
  &[disabled='disabled'] {
    opacity: 0.5;
    pointer-events: none;
  }
  &:hover {
    opacity: 0.8;
  }
  &.normal {
    ::v-deep {
      span {
        color: #2d2c2b;
        font-size: 14px;
        letter-spacing: 0;
        text-align: center;
        line-height: 14px;
        font-weight: 600;
      }
    }
  }
  &.btn_text {
    cursor: pointer;
    border: 0;
    white-space: nowrap;
    padding: 0;
    border-radius: 0;
    color: var(--main-text-color);
    background: none;
  }
  &.content_empty {
    background: transparent;
    ::v-deep {
      span {
        color: var(--main-text-color);
      }
    }
  }
}
</style>
