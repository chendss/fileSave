<template>
  <div v-if="pageNumber > 0" class="custom_pagination" v-bind="$attrs" v-on="$listeners">
    <span class="total_text">{{ `共 ${total} 条记录` }}</span>
    <Button contentStyle="empty" class="prev" :disabled="['0', '1'].includes(`${currentPage}`)" @click="prev">
      上一页
    </Button>
    <div class="number_box">
      <el-pagination
        background
        layout="pager"
        :page-size="pageSize"
        :total="total"
        :current-page="currentPage"
        @current-change="chosePage"
      />
    </div>
    <Button contentStyle="empty" class="next" :disabled="`${currentPage}` === `${pageNumber}`" @click="next">
      下一页
    </Button>
    <Select v-model="size" :options="options" @change="sizeChange" />
  </div>
</template>

<script>
import { scrollTo } from '@/utils/scroll-to'
import { range } from 'lodash-es'
import Button from '../Button'
import Select from '../Select'
export default {
  components: { Button, Select },
  model: {
    prop: 'currentPage',
    event: 'change',
  },
  props: {
    total: {
      type: Number,
      default: 0,
    },
    currentPage: {
      type: Number,
      default: 1,
    },
    pageCount: {
      type: Number,
      default: 0,
    },
    pageSize: {
      type: Number,
      default: 10,
    },
    pageSizes: {
      type: Array,
      default: () => [10, 20, 30, 40, 50],
    },
  },

  data() {
    return {
      size: 10,
    }
  },
  computed: {
    pageNumber() {
      if (this.pageCount) {
        return this.pageCount
      } else {
        const count = Math.ceil(Number(this.total) / Number(this.pageSize))
        return count
      }
    },
    options() {
      const pageSizes = this.pageSizes
      return pageSizes.map((p) => ({ key: p, value: `${p}条/页` }))
    },
  },
  watch: {
    pageSize(val) {
      this.size = val
    },
  },
  mounted() {
    this.size = this.pageSize
  },
  methods: {
    range,
    sizeChange(size) {
      this.$emit('sizeChange', `${size}`)
      scrollTo(0, 800)
    },
    chosePage(page) {
      this.$emit('change', Number(page))
      scrollTo(0, 800)
    },
    prev() {
      const n = Number(this.currentPage)
      this.$emit('change', Math.max(0, n - 1))
      scrollTo(0, 800)
    },
    next() {
      const n = Math.max(1, Number(this.currentPage))
      this.$emit('change', Math.min(this.pageNumber, n + 1))
      scrollTo(0, 800)
    },
  },
}
</script>

<style lang="scss" scoped>
.custom_pagination {
  padding: 4px 0;
  display: flex;
  align-items: center;
  button {
    padding: 7px 18px;
  }
  ::v-deep {
    .custom_select {
      padding: 8px 10px;
      .option {
        padding: 8px 10px;
      }
    }
  }
  .number_box {
    display: inline-flex;
    align-items: center;
    ::v-deep {
      .number,
      .more {
        width: 30px;
        height: 30px;
        margin: 0;
        position: relative;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border: 1px solid var(--main-text-color);
        border-radius: var(--border);
        padding: 8px 10px;
        cursor: pointer;
        background: transparent;
        font-size: 12px;
        color: var(--main-text-colo);
        letter-spacing: 0;
        text-align: center;
        font-weight: 700;
        &:hover:not(.active, .more) {
          opacity: 0.8;
        }
      }
      .more {
        margin-right: 10px;
        margin-left: 10px;
      }
      .number + .number {
        margin-left: 10px;
      }
    }
  }
  .next {
    margin-right: 10px;
    margin-left: 10px;
  }
  .prev {
    margin-right: 10px;
  }
  .total_text {
    font-size: 12px;
    color: var(--sub-text-color);
    letter-spacing: 0;
    text-align: right;
    font-weight: 400;
    margin-right: 10px;
  }
}
</style>
