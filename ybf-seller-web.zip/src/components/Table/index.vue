<template>
  <div class="custom_table_box">
    <el-table
      v-loading="loading"
      style="width: 100%"
      class="custom_table"
      autoFix
      :data="data"
      :border="false"
      v-bind="$attrs"
      v-on="$listeners"
    >
      <slot />
    </el-table>
    <PaginationPlus
      v-if="enablePagination"
      v-model="pagination.page"
      :class="{ table_pagination: true, loading_pagination: loading }"
      :total="totalElements"
      :pageSize="pagination.pageSize"
      @sizeChange="sizeChange"
      @change="pageChange"
    />
  </div>
</template>

<script>
import { get } from '@/utils/tools'
import PaginationPlus from '../PaginationPlus'
import { chunk } from 'lodash-es'
export default {
  components: { PaginationPlus },
  props: {
    enablePagination: {
      type: Boolean,
      default: true,
    },
    getData: {
      type: Function,
      default: undefined,
    },
    version: {
      type: Number,
      default: 0,
    },
  },
  data() {
    return {
      loading: false,
      total: 0,
      pagination: {
        page: 1,
        pageSize: 20,
      },
      tableData: [],
    }
  },
  computed: {
    data() {
      if (this.total) {
        return this.tableData
      }
      const { pageSize, page } = this.pagination
      const chunkList = chunk(this.tableData, pageSize)
      return get(chunkList, `[${Math.max(0, page - 1)}]`, [])
    },
    totalElements() {
      if (this.total != null) {
        return this.total
      }
      return this.tableData instanceof Array ? this.tableData.length : 0
    },
  },
  watch: {
    version() {
      this.getTableData()
    },
  },
  mounted() {
    this.getTableData()
  },
  methods: {
    sizeChange(size) {
      this.pagination = { pageSize: Number(size), page: 1 }
      this.$emit('sizeChange')
      this.getTableData()
    },
    pageChange(page) {
      this.getTableData()
      this.$emit('pageChange', page)
    },
    getPagination() {
      return this.pagination
    },
    async getTableData() {
      if (this.getData) {
        try {
          this.loading = true
          const res = await this.getData(this.pagination)
          if (!res) {
            return
          }
          this.tableData = get(res, 'content', [])
          this.total = get(res, 'total', 0)
          this.pagination = {
            ...this.pagination,
            pageSize: get(res, 'size', 0),
            page: get(res, 'page', 0),
          }
        } catch (error) {
          console.log('发生错误', error)
        } finally {
          this.$emit('tableRenderOver', { tableData: this.tableData })
          this.loading = false
        }
      }
    },
    getList() {
      return this.tableData
    },
  },
}
</script>

<style lang="scss" scoped>
.custom_table_box {
  display: flex;
  flex-direction: column;
  .table_pagination {
    z-index: 2;
    margin-left: auto;
  }
}
.custom_table {
  background-color: var(--main-bg);
  border-radius: calc(var(--border) / 2);
  border: 1px solid #3a3938;
  margin-bottom: 20px;
  &::before {
    background-color: var(--main-bg);
  }
  ::v-deep {
    table {
    }
    &.el-table--scrollable-x {
    }
    .el-table__header {
      thead {
        tr {
          background-color: var(--main-bg);
        }
        .el-table__cell {
          background-color: var(--main-bg);
          padding: 0;
          border-bottom: 1px solid #3a3938;
          .cell {
            border: none;
            font-size: 12px;
            color: #888683;
            letter-spacing: 0;
            text-align: center;
            padding: 12px 6px;
            line-height: 12px;
            font-weight: 400;
            padding: 16px 0;
          }
        }
      }
    }
    .el-table__body-wrapper {
      tbody {
        background-color: var(--main-bg);
        .el-table__row {
          background-color: var(--main-bg);
          &:hover {
            background-color: var(--container-bg);
            td {
              background-color: var(--container-bg);
            }
            .cell {
            }
          }
          padding: 0;
          td {
            padding: 0;
            border: none;
            text-align: center;
            .cell {
              display: inline-flex;
              padding: 12px 6px;
              font-size: 12px;
              color: #ffffff;
              letter-spacing: 0;
              line-height: 12px;
              font-weight: 400;
            }
          }
        }
      }
      .el-table__row {
        &:last-child {
          .cell {
            /* padding-bottom: 26px; */
          }
        }
      }
    }
  }
}

.loading_pagination {
  /* opacity: 0; */
}
</style>
