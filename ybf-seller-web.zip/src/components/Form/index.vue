<template>
  <el-form class="custom_form" v-bind="$attrs" v-on="$listeners">
    <slot />
  </el-form>
</template>

<script>
export default {}
</script>

<style lang="scss" scoped>
.custom_form {
  ::v-deep {
    .custom_form_item + .custom_form_item {
      margin-top: 26px;
    }
  }
}
</style>
