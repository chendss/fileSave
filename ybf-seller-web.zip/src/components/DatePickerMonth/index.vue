<template>
  <el-date-picker
    v-model="pickerValue"
    class="custom_data_picker_month"
    type="daterange"
    range-separator=""
    popper-class="custom_data_picker_month_popper"
    value-format="yyyy-MM-dd"
    start-placeholder="开始日期"
    end-placeholder="结束日期"
    @change="change"
  />
</template>

<script>
export default {
  model: {
    prop: 'value',
    event: 'change',
  },
  props: {
    value: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      pickerValue: [],
    }
  },
  watch: {
    value(val) {
      this.pickerValue = val
    },
  },
  mounted() {
    this.pickerValue = this.value
  },
  methods: {
    change(vars) {
      this.$emit('change', vars || [])
    },
  },
}
</script>

<style lang="scss" scoped>
.custom_data_picker_month {
  width: 280px;
  height: 40px;
  background: transparent;
  border-radius: var(--border);
  border: 1px solid var(--main-text-color);
  padding: 3px 0 3px 10px;
  position: relative;
  ::v-deep {
    .el-input__icon {
      margin-top: 2px;
    }
    .el-range-separator {
      width: 12px;
      margin-top: 2px;
      position: relative;
      &::before {
        top: 0;
        bottom: 0;
        content: '';
        left: 0;
        width: 100%;
        height: 1px;
        margin: auto;
        position: absolute;
        background: var(--main-text-color);
      }
    }
    .el-range-input {
      background: transparent;
      font-size: 12px;
      color: var(--main-text-color);
      &:last-child {
      }
      &::-webkit-input-placeholder {
        color: var(--main-text-color);
        opacity: 0.8;
      }
      :-moz-placeholder {
        color: var(--main-text-color);
        opacity: 0.8;
      }
      &::-moz-placeholder {
        color: var(--main-text-color);
        opacity: 0.8;
      }
      &:-ms-input-placeholder {
        color: var(--main-text-color);
        opacity: 0.8;
      }
      &::-ms-input-placeholder {
        color: var(--main-text-color);
        opacity: 0.8;
      }
    }
    .el-range__close-icon {
      margin-top: 3px;
      position: absolute;
      float: none;
      right: 8px;
      &::after {
      }
    }
    i {
      color: var(--main-text-color);
    }
  }
}
</style>

<style lang="scss">
.custom_data_picker_month_popper {
  background: var(--main-bg);
  margin-top: 7px !important;
  overflow: hidden;
  border: 1px solid var(--split-border-color);
  border-radius: var(--border);
  .el-date-range-picker__header {
    color: var(--sub-text-color);
  }
  .popper__arrow {
    margin-top: -1px;
    border-bottom-color: var(--main-bg) !important;
    &::after {
      border-bottom-color: var(--main-bg) !important;
    }
  }
  .el-date-table {
    background: var(--main-bg);
    tbody {
      tr {
        th {
          border-bottom: 1px solid var(--split-border-color);
        }
      }
    }
  }
  .el-picker-panel__body-wrapper {
    background: var(--main-bg);
  }
  .el-picker-panel__content {
    border-radius: var(--border) 0 0 var(--border);
    background: var(--main-bg);
    border-right: 1px solid var(--split-border-color);
  }
  .el-picker-panel__content + .el-picker-panel__content {
    border-right: none;
  }
  .el-picker-panel__body {
    border-radius: var(--border);
    background: var(--main-bg);
  }
  .prev-month {
    span {
      color: var(--sub-text-color);
      opacity: 0.85;
    }
  }
  .available {
    span {
      color: var(--sub-text-color);
    }
  }
  .available.in-range {
    span {
      background: transparent;
    }
    &.end-date {
      span {
        color: var(--main-bg);
        background: var(--main-text-color);
      }
    }
    &.start-date {
      span {
        color: var(--main-bg);
        background: var(--main-text-color);
      }
    }
    div {
      background: var(--container-bg);
      &:hover {
        background: var(--container-bg);
        border: none;
      }
    }
  }
}
</style>
