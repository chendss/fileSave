<template>
  <div>
    <el-button
      type="info"
      @click="getReset"
    >{{ submitText }}</el-button>
  </div>
</template>

<script>
export default {
  props: {
    submitText: {
      type: String,
      default: '重置'
    }
  },
  methods: {
    getReset() {
      this.$emit('getReset')
    }
  }
}
</script>
