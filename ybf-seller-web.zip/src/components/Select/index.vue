<template>
  <div
    ref="select"
    :class="{ custom_select: true, flat: type === 'flat', detail_open: open, readonly }"
    v-bind="$attrs"
    @click="toggleSelect"
    v-on="$listeners"
  >
    <div ref="optionsBox" :class="{ custom_options_box: true, open, top: direction === 'top' }">
      <div class="custom_options">
        <div
          v-for="item in options"
          :key="item.key"
          :label="item.value"
          :value="item.key"
          :class="{ option: true, active: `${value}` === `${item.key}` }"
          @click="change(item)"
        >
          <span>{{ item.value }}</span>
        </div>
      </div>
    </div>
    <span class="content_text">{{ text }}</span>
    <img v-if="DownIcon" :src="DownIcon" class="icon" />
  </div>
</template>

<script>
import { getEventPath } from '@/utils/tools'
import DownIcon from '@/assets/images/down_jt.png'
let userCount = 0
export default {
  model: {
    prop: 'value',
    event: 'change',
  },
  props: {
    options: {
      type: Array,
      default: () => [],
    },
    value: {
      type: [String, Number],
      default: '',
    },
    type: {
      type: String,
      default: '',
    },
    readonly: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      userCount,
      DownIcon,
      open: false,
      direction: 'bottom',
    }
  },
  computed: {
    text() {
      const item = this.options.find((o) => `${o.key}` === `${this.value}`)
      return item ? item.value : '全部状态'
    },
  },
  mounted() {
    document.addEventListener('click', this.clickOther)
  },
  methods: {
    clickOther(e) {
      const path = getEventPath(e)
      const select = this.$refs['select']
      if (select) {
        if (!path.includes(select)) {
          this.open = false
        }
      }
    },
    getPopDirection() {
      const bodyRect = document.body.getBoundingClientRect()
      const { select } = this.$refs
      const selectRect = select.getBoundingClientRect()
      const topH = selectRect.top
      const bottomH = bodyRect.height - selectRect.bottom
      return bottomH > topH ? 'bottom' : 'top'
    },
    toggleSelect() {
      const d = this.getPopDirection()
      this.direction = d
      setTimeout(() => {
        console.log(1)
        this.open = !this.open
      }, 100)
    },
    change(item) {
      this.$emit('change', `${item.key}`)
    },
  },
}
</script>

<style lang="scss" scoped>
.custom_select {
  padding: 14px 10px;
  position: relative;
  align-items: center;
  display: inline-flex;
  cursor: pointer;
  justify-content: flex-start;
  border-radius: var(--border);
  border: 1px solid var(--main-text-color);
  &.readonly {
  }
  &.detail_open {
    z-index: 999;
  }
  &.flat {
    height: 40px;
  }
  .icon {
    width: 7px;
    height: 6px;
    margin-left: auto;
  }
  .custom_options_box {
    position: absolute;
    left: 0;
    top: 100%;
    width: 100%;
    display: flex;
    overflow: hidden;
    visibility: hidden;
    transform: translate(0, 6px);
    .custom_options {
      transform: translate(0, -100%);
      overflow: hidden;
      max-height: 999px;
      bottom: 0;
      opacity: 0;
      width: 100%;
      display: flex;
      pointer-events: none;
      background: var(--main-bg);
      flex-direction: column;
      border-radius: var(--border);
      border: 1px solid var(--main-text-color);
      transition: all 0.2s;
      .option {
        pointer-events: auto;
        position: relative;
        z-index: 1;
        overflow: hidden;
        background: var(--main-bg);
        border: none;
        white-space: nowrap;
        align-items: center;
        display: inline-flex;
        justify-items: center;
        padding: 14px 10px;
        height: auto;
        width: 100%;
        min-height: 40px;
        cursor: pointer;
        &.active {
          background: var(--container-bg);
        }
        &:hover {
          background: var(--container-bg);
        }
        span {
          display: inline-flex;
          font-size: 12px;
          color: var(--main-text-color);
          letter-spacing: 0;
          line-height: 12px;
          font-weight: 400;
        }
      }
    }

    &.top {
      top: 0;
      transform: translate(0, calc(-100% - 6px));
      .custom_options {
        transform: translate(0, 100%);
      }
      &.open {
        .custom_options {
          opacity: 1;
          transform: translate(0, 0);
        }
      }
    }

    &.open {
      visibility: visible;
      .custom_options {
        opacity: 1;
        transform: translate(0, 0);
      }
    }
  }
  .content_text {
    cursor: pointer;
    font-size: 12px;
    color: var(--main-text-color);
    letter-spacing: 0;
    line-height: 12px;
    font-weight: 400;
    width: 58px;
  }
}
</style>
