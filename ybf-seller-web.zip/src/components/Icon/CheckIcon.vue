<template>
  <img class="custom_icon_check" :src="src" v-bind="$attrs" v-on="$listeners" @click="toggle" />
</template>

<script>
import Yes from '@/assets/images/radio_yes.png'
import No from '@/assets/images/radio_no.png'
export default {
  model: {
    prop: 'value',
    event: 'change',
  },
  props: {
    value: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      Yes,
      No,
    }
  },
  computed: {
    src() {
      return this.value === true ? Yes : No
    },
  },
  methods: {
    toggle() {
      this.$emit('change', !this.value)
    },
  },
}
</script>

<style lang="scss" scoped>
.custom_icon_check {
  width: 18px;
  height: 18px;
  cursor: pointer;
}
</style>
