<template>
  <div :class="{ custom_radio: true, check: value }" @click="toggleValue">
    <div class="circle" />
    <span>{{ text }}</span>
    <slot />
  </div>
</template>

<script>
export default {
  model: {
    prop: 'value',
    event: 'change',
  },
  props: {
    text: {
      type: String,
      default: '',
    },
    value: {
      type: Boolean,
      default: false,
    },
    readonly: {
      type: Boolean,
      default: false,
    },
  },
  methods: {
    toggleValue() {
      if (!this.readonly) {
        this.$emit('change', !this.value)
      }
    },
  },
}
</script>

<style lang="scss" scoped>
.custom_radio {
  padding: 12px 20px;
  display: inline-flex;
  align-items: center;
  justify-content: flex-start;
  background: var(--main-bg);
  border: 1px solid var(--split-border-color);
  border-radius: var(--border);
  font-size: 14px;
  cursor: pointer;
  line-height: 14px;
  &.check {
    .circle {
      &::after {
        width: 6px;
        height: 6px;
      }
    }
  }
  .circle {
    position: relative;
    width: 14px;
    height: 14px;
    border-radius: 100%;
    border: 1px solid var(--main-text-color);
    margin-right: 6px;
    &::after {
      transition: all 0.3s;
      content: '';
      position: absolute;
      top: 0;
      bottom: 0;
      left: 0;
      right: 0;
      margin: auto;
      width: 0px;
      height: 0px;
      border-radius: 100%;
      background: var(--main-text-color);
    }
  }
  span {
    font-size: 14px;
    color: var(--main-text-color);
    letter-spacing: 0;
    line-height: 14px;
    font-weight: 400;
  }
}
</style>
