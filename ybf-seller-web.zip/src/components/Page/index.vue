<template>
  <div class="view_content" v-bind="$attrs" v-on="$listeners">
    <slot />
  </div>
</template>

<script>
export default {
  components: {},
}
</script>

<style lang="scss" scoped></style>
