<template>
  <div class="table_empty_box">
    <div class="content">
      <img :src="Empty" />
      <slot />
    </div>
  </div>
</template>

<script>
import Empty from '@/assets/images/no_img.png'
export default {
  data() {
    return {
      Empty,
    }
  },
}
</script>

<style lang="scss" scoped>
.table_empty_box {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 80px 0;
  justify-content: center;
  background: var(--main-bg);
  border: 1px solid #3a3938;
  border-radius: calc(var(--border) / 2);
  .content {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    img {
      width: 305px;
      height: 135px;
    }
  }
}
</style>
