<template>
  <div class="custom_check" @click="toggle">
    <CheckIcon v-model="checked" />
    <span :class="{ checked }">{{ text }}</span>
  </div>
</template>

<script>
import { CheckIcon } from '../Icon'
export default {
  components: { CheckIcon },
  model: {
    prop: 'value',
    event: 'change',
  },
  props: {
    value: {
      type: Boolean,
      default: () => false,
    },
    text: {
      type: String,
      default: () => '',
    },
  },
  data() {
    return {
      checked: false,
    }
  },
  watch: {
    value(val) {
      this.checked = val
    },
  },
  mounted() {
    this.checked = this.value
  },
  methods: {
    toggle() {
      this.$emit('change', !this.checked)
    },
  },
}
</script>

<style lang="scss" scoped>
.custom_check {
  display: flex;
  width: 100%;
  height: max-content;
  align-items: center;
  span {
    cursor: pointer;
    margin-left: 4px;
    font-size: 14px;
    letter-spacing: 0;
    line-height: 14px;
    font-weight: 400;
    color: var(--sub-text-color);
    &.checked {
      color: var(--main-text-color);
    }
  }
}
</style>
