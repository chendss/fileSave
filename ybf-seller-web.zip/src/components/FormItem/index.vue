<template>
  <el-form-item
    :class="{ custom_form_item: true, placeholder: !!placeholder || hasPlaceholder, hasRightPlaceholder }"
    v-bind="$attrs"
    v-on="$listeners"
  >
    <slot />
    <div v-if="placeholder || hasPlaceholder" class="form_item_placeholder">
      <span v-if="!hasPlaceholder">{{ placeholder }}</span>
      <slot name="placeholder" class="form_item_placeholder" />
    </div>
    <div v-if="hasRightPlaceholder" class="right_placeholder">
      <slot name="rightPlaceholder" class="form_item_right_placeholder" />
    </div>
  </el-form-item>
</template>

<script>
export default {
  props: {
    placeholder: {
      type: String,
      default: () => '',
    },
  },
  computed: {
    hasPlaceholder() {
      return !!this.$scopedSlots.placeholder
    },
    hasRightPlaceholder() {
      return !!this.$scopedSlots.rightPlaceholder
    },
  },
}
</script>

<style lang="scss" scoped>
.custom_form_item {
  display: flex;
  justify-content: flex-start;
  margin-bottom: 0;
  position: relative;

  &.hasRightPlaceholder {
    .right_placeholder {
      position: absolute;
      right: 0;
      top: 0;
      bottom: 0;
      height: 40px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      transform: translate(calc(100% + 10px), 0);
      font-size: 12px;
      color: var(--sub-text-color);
      letter-spacing: 0;
      line-height: 12px;
    }
  }
  &.placeholder {
    /* padding-bottom: 22px; */
  }
  .form_item_placeholder {
    margin-top: 10px;
    color: var(--sub-text-color);
    letter-spacing: 0;
    font-size: 12px;
    line-height: 12px;
  }
  ::v-deep {
    .el-form-item__label {
      height: 100%;
      width: 184px;
      display: inline-flex;
      justify-content: flex-end;
      margin-right: 40px;
      padding-right: 0;
      height: 40px;
      align-items: center;
    }
    .el-form-item__content {
      width: 375px;
      min-height: 40px;
      .custom_select,
      .custom_radio,
      .custom_input {
        height: 40px;
        width: 100%;
      }
      margin-left: 0 !important;
    }
  }
}
</style>
