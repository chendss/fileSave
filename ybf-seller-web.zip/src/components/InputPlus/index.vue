<template>
  <el-input
    v-model="inputValue"
    :class="{ custom_input: true, prefix: hasPreFixSlot, suffix: hasSuffixSlot, readonly }"
    v-bind="$attrs"
    oninput="value=value.replace(/[^0-9.]/g,'')"
    @blur="blur"
    @input="change"
    v-on="$listeners"
  >
    <template slot="prefix">
      <slot name="prefix" />
    </template>
    <template slot="suffix">
      <slot name="suffix" />
    </template>
  </el-input>
</template>

<script>
import { isNaN } from 'lodash-es'
import { formatNumber } from '@/utils/mathe'
import BigNumber from 'bignumber.js'
export default {
  model: {
    prop: 'value',
    event: 'change',
  },
  props: {
    value: {
      type: String,
      default: () => '',
    },
    readonly: {
      type: Boolean,
      default: false,
    },
    valueType: {
      type: String,
      default: 'string',
    },
    floatLength: {
      type: Number,
      default: undefined,
    },
    coin: {
      type: String,
      default: undefined,
    },
    max: {
      type: [String, Number],
      default: undefined,
    },
    min: {
      type: [String, Number],
      default: undefined,
    },
  },
  data() {
    return {
      inputValue: '',
    }
  },
  computed: {
    hasPreFixSlot() {
      return !!this.$scopedSlots.prefix
    },
    hasSuffixSlot() {
      return !!this.$scopedSlots.suffix
    },
  },
  watch: {
    value(val) {
      this.inputValue = val
    },
  },
  mounted() {
    this.inputValue = this.getValue()
  },
  methods: {
    restrictionValue(val) {
      const value = val || this.value
      const { min, max } = this
      let result = value
      if (min != null || max != null) {
        const vb = BigNumber(value)
        if (min) {
          const mb = BigNumber(min)
          if (vb.comparedTo(mb) === -1) {
            return min
          }
        }
        if (max) {
          const maxB = BigNumber(max)
          if (vb.comparedTo(maxB) === 1) {
            return max
          }
        }
        return result
      }
      return value
    },
    getValue(val) {
      const value = val || this.value
      if (this.valueType === 'string') {
        return value
      } else if (this.valueType === 'number') {
        const { coin, floatLength } = this
        return formatNumber(value, coin, floatLength, false)
      }
      return value
    },
    change(val) {
      this.$emit('change', val)
    },
    blur() {
      const value = this.value
      const { coin, floatLength } = this
      if (this.valueType === 'number') {
        const v = this.restrictionValue(value)
        this.$emit('change', formatNumber(v, coin, floatLength, false))
      }
    },
  },
}
</script>

<style lang="scss" scoped>
.custom_input {
  border-radius: var(--border);
  background: transparent;
  &.readonly {
    pointer-events: none;
  }
  &.prefix {
    ::v-deep {
      input {
        padding-left: 24px;
      }
    }
  }
  ::v-deep {
    .el-input__suffix {
      right: 0;
    }
    .el-input__suffix-inner {
      display: inline-flex;
      height: 100%;
    }
    .el-input__prefix {
      color: var(--sub-text-color);
      letter-spacing: 0;
      line-height: 14px;
      font-weight: 600;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      left: 10px;
    }
    input {
      padding-left: 10px;
      background: transparent;
      height: 40px;
      outline: none;
      line-height: 40px;
      border-color: var(--input-border-color);
      font-size: 14px;
      color: var(--main-text-color);
      letter-spacing: 0;
      line-height: 14px;
      font-weight: 700;
      &:focus {
        border-color: var(--main-text-color);
      }
      &::-webkit-input-placeholder {
        font-size: 12px;
        color: var(--sub-text-color);
        letter-spacing: 0;
        line-height: 12px;
        font-weight: 400;
      }
    }
  }
}
</style>
