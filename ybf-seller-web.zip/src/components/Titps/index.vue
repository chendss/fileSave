<template>
  <div :class="{ titps_box: true, [type]: true }">
    <img v-if="type === 'border'" :src="Titps" />
    <img v-else :src="Titps2" />
    <span>{{ text }}</span>
  </div>
</template>

<script>
import Titps2 from '@/assets/images/tips_q@2x.png'
import Titps from '@/assets/images/tips.png'
export default {
  props: {
    text: {
      type: String,
      default: '',
    },
    type: {
      type: String,
      default: 'border',
    },
  },
  data() {
    return { Titps, Titps2 }
  },
}
</script>

<style lang="scss" scoped>
.titps_box {
  padding: 8px 10px;
  align-items: center;
  justify-content: flex-start;
  overflow: hidden;
  display: inline-flex;
  width: max-content;
  white-space: nowrap;
  &.border {
    background: #888683;
    border-radius: var(--border);
  }
  img {
    width: 14px;
    height: 14px;
  }
  span {
    padding-left: 6px;
    font-size: 12px;
    color: var(--container-bg);
    letter-spacing: 0;
    line-height: 12px;
    font-weight: 400;
  }
}
</style>
