<template>
  <el-dialog class="custom_dialog" v-bind="$attrs" v-on="$listeners">
    <slot />
  </el-dialog>
</template>

<script>
export default {
  props: {},
}
</script>

<style lang="scss" scoped>
.custom_dialog {
  ::v-deep {
    .el-dialog {
      overflow: hidden;
      margin-top: 110px !important;
      background: var(--container-bg);
      border-radius: var(--border);
      .el-dialog__header {
        padding: 16px 20px;
        background: var(--main-bg);
        position: relative;
        .el-dialog__title {
          font-size: 16px;
          color: var(--main-text-color);
          letter-spacing: 0;
          line-height: 16px;
          font-weight: 400;
        }
        .el-dialog__headerbtn {
          top: 0;
          bottom: 0;
        }
      }
      .el-dialog__body {
        padding: 16px 20px 20px 20px;
      }
    }
  }
}
</style>

<style lang="scss">
.v-modal {
  opacity: 0.8;
  background: #0e0e0d;
}
</style>
