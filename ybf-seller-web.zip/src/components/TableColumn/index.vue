<template>
  <el-table-column v-if="hasSlot" align="center" :formatter="formatter" fit v-bind="$attrs" v-on="$listeners">
    <template slot-scope="scope">
      <slot v-bind="scope" />
    </template>
  </el-table-column>
  <el-table-column v-else align="center" :formatter="formatter" v-bind="$attrs" v-on="$listeners" />
</template>

<script>
import { get, transSelectOptionsToObj } from '@/utils/tools'
import {
  getTableValue,
  getTableTimeValue,
  getTableEnumValue,
  getTradingPair,
  getUnitPrice,
  getNumber,
} from '@/utils/table'
export default {
  props: {
    valueType: {
      type: String,
      default: 'value',
    },
    enumType: {
      type: Object,
      default: () => ({}),
    },
    enumKey: {
      type: String,
      default: '',
    },
    defaultValue: {
      type: String,
      default: '/',
    },
    pairKeys: {
      type: Array,
      default: () => [],
    },
    coinKey: {
      type: String,
      default: undefined,
    },
    coinType: {
      type: String,
      default: undefined,
    },
    floatLength: {
      type: Number,
      default: undefined,
    },
    numberGroup: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {}
  },
  computed: {
    hasSlot() {
      return !!this.$scopedSlots.default
    },
  },
  methods: {
    get,
    transSelectOptionsToObj,
    getTableValue,
    getTableTimeValue,
    getTableEnumValue,
    formatter(row, column, value) {
      const baseFormatter = get(this, '$attrs.formatter', null)
      if (baseFormatter) {
        return baseFormatter(row, column, value)
      }
      const property = get(column, 'property', null)
      let result = value === '' || value == null ? '/' : value
      if (this.valueType === 'value') {
        result = getTableValue(row, column, value)
      } else if (this.valueType === 'time') {
        result = getTableTimeValue(row, column, value)
      } else if (this.valueType === 'enum') {
        const enumKey = get(this, 'enumKey', '') || property
        result = getTableEnumValue(row, property, this.enumType, enumKey)
      } else if (this.valueType === 'pair' && this.pairKeys.length === 2) {
        result = getTradingPair(row, this.pairKeys)
      } else if (this.valueType === 'unitPrice') {
        result = getUnitPrice(row, property)
      } else if (this.valueType === 'number') {
        const coin = get(row, `${this.coinKey}`, this.coinType)
        result = getNumber(row, property, coin, this.floatLength, this.numberGroup)
      }
      if (['/', 'undefined', 'null'].includes(`${result}`)) {
        return this.defaultValue
      }
      return result
    },
  },
}
</script>

<style lang="scss" scoped></style>
