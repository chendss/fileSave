import { logout } from '@/api/login'
import { getToken, removeToken } from '@/utils/auth'
import router from '@/router/routers'

const user = {
  state: {
    token: getToken(),
    user: {}

  },

  mutations: {
    SET_TOKEN: (state, token) => {
      state.token = token
    },
    SET_USER: (state, user) => {
      state.user = user
    }

  },

  actions: {

    // 登出
    LogOut({ commit }) {
      return new Promise((resolve, reject) => {
        logout()
          .then(res => {
            removeToken()
            location.hash.includes('/login') ? location.reload() : router.push('/login')
            resolve()
          })
          .catch(error => {
            location.hash.includes('/login') ? location.reload() : router.push('/login')
            reject(error)
          })
      })
    }

  }
}

export default user
