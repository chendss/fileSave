import request from '@/utils/request'

// 获取app下载地址
export function fetchDownloadUrl(data) {
  return request({
    url: '/wallet/getAppQrCodeUrl',
    method: 'post',
    data
  })
}
export function getQrCodeId(data) {
  return request({
    url: '/user/webPreferential/getQrCodeId',
    method: 'post',
    data
  })
}

export function getQrCodeState(data) {
  return request({
    url: '/user/webPreferential/getQrCodeState',
    method: 'post',
    data
  })
}

export function logout() {
  return request({
    url: '/user/webPreferential/loginout',
    method: 'post'
  })
}

export function test() {
  return request({
    url: '/user/webPreferential/index',
    method: 'post',
    data: {}
  })
}
