import {
  orderTransactionMap, pendingCreateTypeMap, payMethodMap, legalCurrencyTypeMap, coinTypeMap, symbolMap, getOrderTypeMap
} from '@/utils/mapData'
import request from '@/utils/request'
import { get, jsonParse } from '@/utils/tools'
import { getEnumLabelByObj } from '@/utils/table'
import { Message } from 'element-ui'
import { formatNumber, times } from '@/utils/mathe'
import BigNumber from 'bignumber.js'

const getPayMethodError = (item, key, payOtherType) => {
  if (`${key}` !== '1') {
    return { error: true, errorMessage: '未找到合适报价' }
  } else if (item.bankDisable) {
    return { error: true, errorMessage: '暂不支持此银行' }
  } else if (get(payOtherType, `[${key}]`, '1') + '' !== '1') {
    const msg = payMethodMap[key]
    return { error: true, errorMessage: `暂时关闭${msg}其他人收款方式` }
  }
  return { error: false, errorMessage: '' }
}

/**
* 获得其他人付款开关状态
*
*/
export const getPayMentOtherType = async () => {
  const url = `/user/getPaymentOtherType`
  try {
    const res = await request({
      url,
      method: 'post',
      data: {}
    })
    const resData = get(res, 'data', {})
    console.log(`${url} 接口出参`, resData)
    return resData
  } catch (error) {
    console.log(`接口爆炸 ${url}`, error)
    return null
  }
}

/**
* 获得付款方式
*
* @returns
*/
export const getPayMethods = async () => {
  const url = `/user/getPaymentInfoMap`
  try {
    const payOtherType = await getPayMentOtherType()
    const res = await request({
      url,
      method: 'post',
      data: {}
    })
    const resData = get(res, 'data', {})
    const result = Object.keys(resData).reduce((pre, key) => {
      const item = resData[key]
      if (item instanceof Array) {
        pre.push(...(item.map(e => {
          const { error, errorMessage } = getPayMethodError(e, key, payOtherType)
          return {
            ...e,
            isError: error,
            errorMessage,
            payMethodType: key
          }
        })))
      } else {
        const { error, errorMessage } = getPayMethodError(item, key, payOtherType)
        pre.push({
          ...item,
          isError: error,
          errorMessage,
          payMethodType: key
        })
      }
      return pre
    }, []).filter(item => `${item.status}` === '1')
    console.log(`${url} 接口出参`, result, resData)
    return result
  } catch (error) {
    console.log(`接口爆炸 ${url}`, error)
    return null
  }
}

/**
* 获得分时段计价
*
* @returns
*/
export const getPreferentialSellPrice = async () => {
  const url = `/otc/getPreferentialSellPrice`
  try {
    const res = await request({
      url,
      method: 'post',
      data: { assetType: '1', currencyType: '-1' }
    })
    const resData = get(res, 'data', {})
    return resData
  } catch (error) {
    console.log(`接口爆炸 ${url}`, error)
    return null
  }
}

/**
* 发布特惠出售挂单
*
* @param {*} data
* @returns
*/
export const publishPendingOrder = async (data) => {
  const url = `/otc/publishSellCommitment`
  try {
    const res = await request({
      url,
      method: 'post',
      data
    })
    console.log(`${url} 接口入参`, data)
    const resData = get(res, 'data', {})
    console.log(`${url} 接口出参`, resData)
    return resData
  } catch (error) {
    const code = get(error, 'code', '4325') + ''
    const msg = get(error, 'msg', '')
    const msgJson = jsonParse(msg)
    if (code === '4325') {
      const message = Object.values(msgJson).join('\n')
      Message.error(message)
      return { code }
    }
    console.log(`接口爆炸 ${url}`, error)
    return null
  }
}

/**
* 发布特惠出售挂单 - 预检查
*
* @param {*} data
* @returns
*/
export const checkPublishPendingOrder = async (data) => {
  const url = `/otc/checkTradeOrderSellPredict`
  try {
    const res = await request({
      url,
      method: 'post',
      data
    })
    console.log(`${url} 接口入参`, data)
    const resData = get(res, 'data', {})
    console.log(`${url} 接口出参`, resData)
    return resData
  } catch (error) {
    console.log(`接口爆炸 ${url}`, error)
    const msg = `${get(error, 'msg', '')}`
    if (msg) {
      Message.error(msg)
    }
    return null
  }
}

/**
* 获得我的挂单列表
*
* @returns
*/
export const getList = async (data) => {
  const url = `/otc/getCommitmentOrdersPageable`
  try {
    console.log(`${url} 接口入参`, data)
    const res = await request({ url, method: 'post', data })
    const resData = get(res, 'data', {})
    const content = get(resData, 'records', []).map(r => {
      const orderTypeStr = orderTransactionMap[`${get(r, 'orderType', '')}`]
      const createTypeStr = pendingCreateTypeMap[`${get(r, 'createType', '')}`]
      const coinType = get(r, 'coinType', '')
      const coinTypeStr = getEnumLabelByObj(coinType, coinTypeMap)
      const legalCurrencyStr = getEnumLabelByObj(get(r, 'legalCurrency', ''), legalCurrencyTypeMap)
      const priceStr = `￥${formatNumber(get(r, 'price', ''), coinTypeStr)}/${coinTypeStr}`
      const payMethodStr = get(r, 'paymentTypeList', []).map(type => payMethodMap[`${type}`]).join(',')
      const pairStr = `${legalCurrencyStr}/${coinTypeStr}`
      const price = get(r, 'price', '0')
      const amountLegalCurrency = times(get(r, 'amount', '0'), price)
      const finishTradeAmountLegalCurrency = times(get(r, 'finishTradeAmount', '0'), price)
      const donePriceStr = `￥${formatNumber(finishTradeAmountLegalCurrency, legalCurrencyStr)}/${amountLegalCurrency}`
      return {
        ...r,
        orderTypeStr,
        createTypeStr,
        typeStr: `${orderTypeStr}-${createTypeStr}`,
        payMethodStr,
        priceStr,
        pairStr,
        coinTypeStr,
        donePriceStr
      }
    })
    const result = {
      ...resData,
      content,
      page: Number(get(resData, 'current', '0')),
      size: Number(get(resData, 'size', '0')),
      total: Number(get(resData, 'total', '0')),
    }
    console.log(`${url} 接口出参`, resData, result)
    return result
  } catch (error) {
    console.log(`接口爆炸 ${url}`, error)
    return null
  }
}

/**
* 下架特惠挂单
*
* @param {*} id
* @returns
*/
export const cancelPendingOrder = async (id) => {
  const url = `/otc/cancelCommitmentOrder`
  try {
    const res = await request({
      url,
      method: 'post',
      data: { id }
    })
    console.log(`${url} 接口入参`, id, { id })
    const resData = get(res, 'data', {})
    console.log(`${url} 接口出参`, resData)
    return resData
  } catch (error) {
    console.log(`接口爆炸 ${url}`, error)
    const msg = `${get(error, 'msg', '')}`
    if (msg) {
      Message.error(msg)
    }
    return null
  }
}

/**
* 查询除了特惠挂单以外的挂单
*
* @returns
*/
export const queryInTransactionOrderPendingCount = async () => {
  const url = `/otc/queryInTransactionOrderPendingCount`
  try {
    const res = await request({
      url,
      method: 'post',
      data: { otcTradeTypeEnum: 0 }
    })
    console.log(`${url} 接口入参`, { otcTradeTypeEnum: 0 })
    const resData = get(res, 'data', {})
    console.log(`${url} 接口出参`, resData)
    return resData
  } catch (error) {
    console.log(`接口爆炸 ${url}`, error)
    const msg = `${get(error, 'msg', '')}`
    if (msg) {
      Message.error(msg)
    }
    return null
  }
}

/**
* 获得币币交易订单的详情
*
* @returns
*/
export const getCommitmentOrderDetail = async (id) => {
  const url = `/otc/getCommitmentOrderDetail`
  try {
    const res = await request({
      url,
      method: 'post',
      data: { id: id },
      silence: true
    })
    console.log(`${url} 接口入参`, { id: id })
    const resData = get(res, 'data', {})
    const totalFrozenAmount = get(resData, 'totalFrozenAmount', '')
    const result = {
      ...resData,
      legalCurrency: legalCurrencyTypeMap['-1'],
      coinType: coinTypeMap[get(resData, 'coinType', '')],
      totalFrozenAmount: BigNumber(totalFrozenAmount).toString()
    }
    console.log(`${url} 接口出参`, result)
    return result
  } catch (error) {
    return null
  }
}

/**
* 根据挂单id查询订单
*
* @returns
*/
export const getDetailList = async (data) => {
  const url = `/otc/getTradeOrderPageable`
  try {
    const res = await request({
      url,
      method: 'post',
      data,
      silence: true
    })
    console.log(`${url} 接口入参`, data)
    const resData = get(res, 'data', {})
    const content = get(resData, 'records', []).map(r => {
      const legalCurrency = get(r, 'legalCurrency', '')
      const legalCurrencySymbol = symbolMap[legalCurrency]
      const orderTypeStr = orderTransactionMap[`${get(r, 'orderType', '')}`]
      const createTypeStr = pendingCreateTypeMap[`${get(r, 'createType', '')}`]
      const payMethodStr = getEnumLabelByObj(get(r, 'paymentType', ''), payMethodMap)
      const legalCurrencyStr = getEnumLabelByObj(legalCurrency, legalCurrencyTypeMap)
      const coinType = get(r, 'coinType', '')
      const coinTypeStr = getEnumLabelByObj(coinType, coinTypeMap)
      const priceStr = `${legalCurrencySymbol}${formatNumber(get(r, 'price', ''), legalCurrencyStr)} / ${coinTypeStr}`
      const pairStr = `${legalCurrencyStr}/${coinTypeStr}`
      const orderTypeMap = getOrderTypeMap(get(r, 'orderType', ''))
      const status = get(r, 'status', '')
      const statusStr = get(orderTypeMap, `[${status}]`, '/')
      const isCancel = `${status}` === '-1'
      const dealAmount = get(r, 'dealAmount', '')
      const transformNumber = `${formatNumber(dealAmount, coinTypeStr)} ${coinTypeStr}`
      const legalCurrencyAmount = get(r, 'legalCurrencyAmount', '')
      const legalCurrencyAmountStr = `${legalCurrencySymbol}${formatNumber(legalCurrencyAmount, legalCurrencyStr)}`
      return {
        ...r,
        payMethodStr,
        typeStr: `${orderTypeStr}-${createTypeStr}`,
        coinTypeStr,
        legalCurrencyStr,
        priceStr,
        pairStr,
        statusStr,
        isCancel,
        transformNumber,
        legalCurrencyAmountStr
      }
    })
    const result = {
      ...resData,
      content,
      page: Number(get(resData, 'current', '0')),
      size: Number(get(resData, 'size', '0')),
      total: Number(get(resData, 'total', '0')),
    }
    console.log(`${url} 接口出参`, resData)
    return result
  } catch (error) {
    return null
  }
}

/**
* 检查特惠卖家是否关闭
*
* @returns
*/
export const checkPreferentialOpen = async () => {
  const url = `/otc/getOtcTradeConfigMap`
  const data = { 'coinType': 1, 'tradeType': 1, 'legalCurrency': -1 }
  // otc特惠卖家挂单维护
  // preferSeller-open 特惠卖家挂单开关
  try {
    const res = await request({
      url,
      method: 'post',
      data,
    })
    console.log(`${url} 接口入参`, data)
    const resData = get(res, 'data', {})
    const open = get(resData, 'preferSeller.open', true)
    console.log(`${url} 接口出参`, resData)
    if (!open) {
      return '已关闭特惠挂单，请联系客服'
    }
    return ''
  } catch (error) {
    console.log(`接口爆炸 ${url}`, error)
    return null
  }
}

/**
* 检查 otc交易配置 - 挂单出售维护
*
* @returns String
*/
export const checkOtcSellMaintain = async () => {
  const url = `/otc/getOtcTransactionPriceSeller`
  const data = { 'coinType': 1, 'orderType': 1, 'otcPriceType': null, 'priceUnit': -1 }
  try {
    const res = await request({ url, method: 'post', data, })
    console.log(`${url} 接口入参`, data)
    const resData = get(res, 'data', {})
    console.log(`${url} 接口出参`, resData)
    return ''
  } catch (error) {
    console.log(`接口爆炸 ${url}`, error)
    const code = get(error, 'code', '')
    const msg = `${get(error, 'msg', '')}`
    if (msg && `${code}` === '307') {
      return msg
    }
    return ''
  }
}

/**
* 检查 otc交易配置 - 下单USDT渠道关闭
*
* @returns String
*/
export const checkTradeOrderSellPredict = async (digitalCurrencyAmount) => {
  const url = `/otc/checkTradeOrderSellPredict`
  const data = {
    'coinType': 1,
    'paymentType': { '1': ['9990'] },
    digitalCurrencyAmount,
    'tradeType': 0,
    'createType': 5,
    'currencyType': -1,
    'accordanceWith': 0
  }
  try {
    const res = await request({ url, method: 'post', data, })
    console.log(`${url} 接口入参`, data)
    const resData = get(res, 'data', {})
    console.log(`${url} 接口出参`, resData)
    return ''
  } catch (error) {
    console.log(`接口爆炸 ${url}`, error)
    const code = get(error, 'code', '')
    const msg = `${get(error, 'msg', '')}`
    if (msg && `${code}` === '52052') {
      return msg
    }
    return ''
  }
}

export default {
  checkTradeOrderSellPredict,
  checkOtcSellMaintain,
  checkPreferentialOpen,
  getList,
  getPayMethods,
  cancelPendingOrder,
  publishPendingOrder,
  getDetailList,
  getCommitmentOrderDetail,
  getPreferentialSellPrice,
  checkPublishPendingOrder,
  queryInTransactionOrderPendingCount,
}
