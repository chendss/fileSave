import request from '@/utils/request'
import { get } from '@/utils/tools'

export const getList = async (data) => {
  console.log('/wallet/queryPreferentialBillPage 接口入参', data)
  try {
    const res = await request({
      url: '/wallet/queryPreferentialBillPage',
      method: 'post',
      data
    })
    const resData = get(res, 'data', {})
    const content = get(resData, 'records', [])
    const result = {
      ...resData,
      content,
      page: Number(get(resData, 'current', '0')),
      size: Number(get(resData, 'size', '0')),
      total: Number(get(resData, 'total', '')),
    }
    console.log('/wallet/queryPreferentialBillPage 接口出参', result)
    return result
  } catch (error) {
    console.log('接口爆炸 /wallet/queryPreferentialBillPage', error)
    return null
  }
}

export default { getList }
