import axios from 'axios'
import request from '@/utils/request'
import { get } from '@/utils/tools'
import { formatNumber } from '@/utils/mathe'
import BigNumber from 'bignumber.js'

export function serverTime () {
  return axios.get(process.env.VUE_APP_BASE_API + '/gw/user/serverTime')
}

export const getFetchBalance = async () => {
  const url = `/wallet/fetchBalance`
  try {
    const res = await request({
      url,
      method: 'post',
      data: { coinTransactionType: '702', coinType: '1' },
      silence: true
    })
    const resData = get(res, 'data', {})
    if (Object.keys(resData).length === 0) return {}
    const amount = get(resData, 'amount', '0')
    const availableAmount = get(resData, 'availableAmount', '0')
    const symbol = get(resData, 'symbol', 'USDT')
    const result = {
      ...resData,
      amount: formatNumber(BigNumber(amount).toString(), symbol, undefined, false),
      availableAmount: formatNumber(BigNumber(availableAmount).toString(), symbol, undefined, false)
    }
    // console.log(`${url} 接口出参`, result)
    return result
  } catch (error) {
    console.log(`接口爆炸 ${url}`, error)
    return null
  }
}

export const getUserId = () => {
  let userId = window.localStorage.getItem('userId')
  const day3 = 3600 * 24 * 3 * 1000
  if (!userId || Date.now() - Math.abs(userId) > day3) {
    userId = -Date.now()
    window.localStorage.setItem('userId', userId)
  }
  return parseInt(userId)
}

export default { getFetchBalance, getUserId }
