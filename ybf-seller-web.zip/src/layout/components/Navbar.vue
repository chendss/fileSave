<template>
  <div class="navbar">
    <div id="id-div-logo">
      <img src="@/assets/images/logo.png" alt="" />
    </div>
    <div id="id-div-seller-button">
      <img src="@/assets/images/th_mj@2x.png" alt="" />
      <span>特惠卖家特供版</span>
    </div>
    <div id="id-div-right-items" class="pointer">
      <img src="@/assets/images/nav_tx@2x.png" alt="" />
      <img src="@/assets/images/nav_service@2x.png" alt="" />
      <img src="@/assets/images/nav_on.png" alt="" @click="logout" />
    </div>
  </div>
</template>

<script>
export default {
  methods: {
    logout() {
      this.$store.dispatch('LogOut')
    },
  },
}
</script>

<style lang="scss" scoped>
.navbar {
  background: #242322;
  width: 100%;
  height: 70px;
  display: flex;
  flex-direction: row;
  align-items: center;

  #id-div-logo {
    width: 80px;
    height: 24px;
    margin-left: 30px;

    img {
      width: 100%;
    }
  }

  #id-div-seller-button {
    width: 153px;
    height: 40px;
    margin-left: 20px;
    display: flex;
    align-items: center;
    background: #2d2c2b;
    border: 1px solid #888683;
    border-radius: 7px;

    img {
      width: 16px;
      height: 18px;
      margin: 0 5px 0 10px;
    }
    span {
      font-size: 16px;
      color: #ddba82;
      letter-spacing: 0;
      text-align: center;
      line-height: 16px;
      font-weight: 400;
    }
  }

  #id-div-right-items {
    position: absolute;
    right: 30px;
    img {
      width: 26px;
      height: 26px;
    }

    img + img {
      margin-left: 20px;
    }
  }
}
</style>
