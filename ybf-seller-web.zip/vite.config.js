import path from 'path'
import { defineConfig, loadEnv } from 'vite'
import vue from '@vitejs/plugin-vue2'
import vueJsx from '@vitejs/plugin-vue2-jsx'
// import commonjs from 'vite-plugin-commonjs'
import eslintPlugin from 'vite-plugin-eslint'
import dotenv from 'dotenv'

export default ({ mode }) => {
  const env = loadEnv(mode, process.cwd())
  dotenv.config({ path: `./.env.${mode}` })
  const envConfig = {
    dev: {
      baseUrl: 'https://dev-ybf-www.dcops.cc'
    },
    test: {
      baseUrl:
      'https://test-ybf-www.dcops.cc'
    },
    rc: {
      baseUrl:
      'https://www.yibifu11.com'
    },
    prod: {
      baseUrl:
      'https://www.yibifu.vip'
    }
  }
  return defineConfig({
    envPrefix: 'VUE_APP_',
    define: {
      'process.env': { ...env, ...process.env }
    },
    resolve: {
      alias: {
        '@': path.resolve(__dirname, 'src')
      },
      extensions: ['.mjs', '.js', '.ts', '.jsx', '.tsx', '.json', '.vue']
    },
    build: {
      commonjsOptions: { transformMixedEsModules: true }
    },
    // optimizeDeps: {
    //   include: ['element-ui']
    // },
    plugins: [
      vue(),
      vueJsx(),
      eslintPlugin({
        include: ['src/**/*.js', 'src/**/*.vue', 'src/*.js', 'src/*.vue']
      })
      // commonjs(),
    ],
    server: {
      open: true,
      port: 4220,
      proxy: {
        '/gw': {
          target: envConfig[mode].baseUrl,
          changeOrigin: true,
          pathRewrite: {
            // '^/gw': ''
          }
        },
        '/RoaVGWBm': {
          target: envConfig[mode].baseUrl,
          changeOrigin: true // 表示是否跨域
        }
      }
    }
  })
}
