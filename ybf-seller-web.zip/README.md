# ybf-seller-web

特惠卖家

- node 版本 >=16

## TODO

- [x] Element 依赖导入
- [x] vue-element-admin 迁移
  - [x] 路由
  - [x] layout 组件
- [x] 添加 axios 请求，本地化改造
  - [x] 移植后台已有的 axios 组件
  - [x] URL 加密请求
- [] fundebug
- [x] permission 权限控制
- [x] Docker 打包处理
- [x] eslint
- [x] editorconfig
